// BabaSitaRam Pro v5.0 — Universal (Chrome + Firefox + Edge + Brave)
// Firefox/Safari polyfill
if (typeof browser !== 'undefined' && typeof chrome === 'undefined') {
  globalThis.chrome = browser;
}

// BabaSitaRam Pro v4.6
(function () {
  if (window.__bsrV50) return;
  window.__bsrV50 = true;

  const site = location.hostname.replace(/^www\./, '').toLowerCase();
  let passwords = [], filledFields = new WeakSet(), scanDone = false, loadRetry = 0;
  let pendingEntry = null; // entry waiting for page 2 password fill

  const SITES = {
    'accounts.google.com':       { u:['input[type="email"]','#identifierId','input[name="identifier"]'],       p:['input[type="password"]','input[name="Passwd"]','input[name="password"]'],          twoPage:true, uNext:'#identifierNext,button[jsname="LgbsSe"],button[type="submit"]', delay:1200 },
    'login.microsoftonline.com': { u:['input[type="email"]','input[name="loginfmt"]','#i0116'],               p:['input[type="password"]','input[name="passwd"]','#i0118'],                           twoPage:true, uNext:'#idSIButton9,button[type="submit"]', delay:1200 },
    'login.live.com':            { u:['input[type="email"]','input[name="loginfmt"]'],                        p:['input[type="password"]'],                                                            twoPage:true, uNext:'#idSIButton9,button[type="submit"]', delay:1000 },
    'twitter.com':               { u:['input[autocomplete="username"]','input[name="text"]'],                 p:['input[type="password"]'],                                                            twoPage:true, uNext:'[data-testid="LoginForm_Login_Button"],div[role="button"]:not([aria-label])', delay:800 },
    'x.com':                     { u:['input[autocomplete="username"]','input[name="text"]'],                 p:['input[type="password"]'],                                                            twoPage:true, uNext:'[data-testid="LoginForm_Login_Button"]', delay:800 },
    'login.yahoo.com':           { u:['#login-username','input[name="username"]'],                           p:['#login-passwd','input[type="password"]'],                                            twoPage:true, uNext:'#login-signin,button[type="submit"]', delay:900 },
    'amazon.in':                 { u:['#ap_email','input[name="email"]'],                                    p:['#ap_password','input[type="password"]'],                                             twoPage:true, uNext:'#continue,input[id="continue"]', delay:800 },
    'amazon.com':                { u:['#ap_email','input[name="email"]'],                                    p:['#ap_password','input[type="password"]'],                                             twoPage:true, uNext:'#continue', delay:800 },
    'facebook.com':              { u:['#email','input[name="email"]'],                                       p:['#pass','input[type="password"]'] },
    'instagram.com':             { u:['input[name="username"]'],                                             p:['input[name="password"]','input[type="password"]'] },
    'linkedin.com':              { u:['#username','input[name="session_key"]'],                              p:['#password','input[name="session_password"]','input[type="password"]'] },
    'onlinesbi.sbi':             { u:['#userId','input[name="userId"]'],                                     p:['#password','input[name="password"]'] },
    'netbanking.hdfcbank.com':   { u:['#fldLoginUserId'],                                                    p:['#fldPassword'] },
    'icicibank.com':             { u:['#userId','input[name="Login1$UserName"]'],                            p:['input[name="Login1$Password"]','input[type="password"]'] },
    'axisbank.com':              { u:['#custid'],                                                            p:['#pass','input[type="password"]'] },
    'netbanking.pnb.co.in':      { u:['#user_id'],                                                          p:['#password','input[type="password"]'] },
    'kotaknet.com':              { u:['#userName'],                                                          p:['#password','input[type="password"]'] },
    'yesbank.in':                { u:['#uid'],                                                               p:['#pwd','input[type="password"]'] },
    'indusind.com':              { u:['#username'],                                                          p:['#password','input[type="password"]'] },
    'idfcfirst.bank.in':         { u:['input[formcontrolname="userId"]','input[placeholder*="User ID" i]','input[placeholder*="Mobile" i]','input[type="tel"]','input[type="text"]:not([readonly]):not([disabled])'], p:['input[type="password"]','input[formcontrolname="password"]'], delay:600, angular:true },
    'idfcfirstbank.com':         { u:['input[formcontrolname="userId"]','input[type="tel"]'],               p:['input[type="password"]'], delay:600, angular:true },
    'airtelbank.com':            { u:['input[name="mobileNumber"]','input[placeholder*="Mobile" i]','input[type="tel"]','input[type="text"]:not([readonly])'], p:['input[type="password"]'], delay:300 },
  };

  const U_SEL = ['input[autocomplete="username"]','input[autocomplete="email"]','input[type="email"]','input[type="tel"]','input[name*="user" i]','input[name*="email" i]','input[name*="login" i]','input[name*="mobile" i]','input[id*="user" i]','input[id*="email" i]','input[id*="login" i]','input[placeholder*="user" i]','input[placeholder*="email" i]','input[placeholder*="mobile" i]','input[placeholder*="login" i]','input[type="text"]:not([readonly]):not([disabled])'];
  const P_SEL = ['input[type="password"]','input[autocomplete="current-password"]','input[autocomplete="new-password"]','input[name*="pass" i]','input[id*="pass" i]','input[placeholder*="pass" i]','input[name*="pin" i]','input[id*="pin" i]','input[name*="pwd" i]'];

  function getCfg() { return Object.entries(SITES).find(([k])=>site.includes(k))?.[1]||null; }

  // ── Load ──
  function loadPw(cb) {
    try {
      chrome.runtime.sendMessage({type:'GET_PASSWORDS'}, res=>{
        if (chrome.runtime.lastError){if(loadRetry++<5)setTimeout(()=>loadPw(cb),1200);return;}
        if (res?.passwords?.length){passwords=res.passwords;loadRetry=0;cb();}
        else if(loadRetry++<14)setTimeout(()=>loadPw(cb),2000);
      });
    } catch(e){if(loadRetry++<5)setTimeout(()=>loadPw(cb),1000);}
  }
  chrome.runtime.onMessage.addListener(msg=>{
    if(msg.type==='VAULT_UNLOCKED'){passwords=msg.passwords||[];loadRetry=0;scanDone=false;setTimeout(scanAndInject,300);}
  });

  function getM(q){
    let list=passwords.filter(p=>{
      const ps=(p.site||'').toLowerCase(),pu=(p.url||'').toLowerCase().replace(/https?:\/\/(www\.)?/,'').split('/')[0];
      return ps&&(site.includes(ps)||ps.includes(site)||(pu&&(site.includes(pu)||pu.includes(site))));
    });
    if(q&&q.trim()){const ql=q.toLowerCase().trim();list=list.filter(p=>(p.user||'').toLowerCase().includes(ql)||(p.site||'').toLowerCase().includes(ql));}
    return list;
  }

  // ── Fill engine ──
  function setVal(el,val){
    const d=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value')||Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
    if(d?.set)d.set.call(el,val);else el.value=val;
    if(el._valueTracker)el._valueTracker.setValue('');
  }
  function fire(el,val){
    if(!el)return;el.focus();setVal(el,val);
    [new Event('focus',{bubbles:true}),
     new KeyboardEvent('keydown',{bubbles:true,cancelable:true,key:'a',keyCode:65,composed:true}),
     new KeyboardEvent('keypress',{bubbles:true,cancelable:true,key:'a',keyCode:65,composed:true}),
     new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:val}),
     new KeyboardEvent('keyup',{bubbles:true,cancelable:true,key:'a',keyCode:65,composed:true}),
     new Event('change',{bubbles:true,composed:true}),
    ].forEach(e=>el.dispatchEvent(e));
    el.dispatchEvent(new Event('ngModelChange',{bubbles:true}));
    setTimeout(()=>{setVal(el,val);el.dispatchEvent(new Event('blur',{bubbles:true}));},100);
  }
  function fillEl(el,val,retries=4){
    if(!el||!val)return;fire(el,val);
    let n=0;const iv=setInterval(()=>{if(el.value===val||n++>=retries){clearInterval(iv);return;}setVal(el,val);el.dispatchEvent(new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:val}));el.dispatchEvent(new Event('change',{bubbles:true}));},200);
  }
  function vis(el){
    if(!el)return false;
    try{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0'&&!el.disabled;}catch(e){return false;}
  }
  function findPw(){
    const c=getCfg();
    if(c?.p)for(const s of c.p){const e=document.querySelector(s);if(e&&vis(e))return e;}
    for(const s of P_SEL){const e=document.querySelector(s);if(e&&vis(e))return e;}
    return null;
  }
  function findU(pwEl){
    const c=getCfg();
    if(c?.u)for(const s of c.u){const e=document.querySelector(s);if(e&&e!==pwEl&&vis(e))return e;}
    const root=pwEl?.closest('form')||pwEl?.closest('[role="main"]')||document;
    for(const s of U_SEL)for(const e of root.querySelectorAll(s))if(e!==pwEl&&vis(e)&&!e.readOnly)return e;
    return null;
  }
  function waitForEl(sels,timeout,cb){
    const start=Date.now();
    const iv=setInterval(()=>{
      for(const s of(sels||[])){const e=document.querySelector(s);if(e&&vis(e)){clearInterval(iv);cb(e);return;}}
      if(Date.now()-start>timeout){clearInterval(iv);cb(null);}
    },200);
  }

  // ─────────────────────────────────────────────────────────────
  // FILL FORM — the KEY fix: store entry, wait for page 2
  // ─────────────────────────────────────────────────────────────
  function fillForm(triggerEl, entry) {
    const cfg=getCfg(); const delay=cfg?.delay||80;

    if(cfg?.twoPage){
      const uSel=cfg.u?.[0], pSel=cfg.p?.[0];
      const uEl=uSel?document.querySelector(uSel):null;
      const pEl=pSel?document.querySelector(pSel):null;
      const uVis=uEl&&vis(uEl), pVis=pEl&&vis(pEl);

      if(uVis&&!pVis){
        // ── PAGE 1: Fill username ──
        fillEl(uEl, entry.user);
        filledFields.add(uEl);

        // Store entry so page 2 can use it
        pendingEntry = entry;
        sessionStorage.setItem('__bsrPending', JSON.stringify({user:entry.user,pw:entry.pw,site:entry.site}));

        // Click Next button
        setTimeout(()=>{
          const nxtSels=(cfg.uNext||'').split(',');
          let nxt=null;
          for(const s of nxtSels){const el=document.querySelector(s.trim());if(el&&vis(el)){nxt=el;break;}}
          if(nxt){nxt.click();}
          // Wait for password field to appear (page 2 loads)
          waitForEl(cfg.p, 4000, pwFld=>{
            if(pwFld&&vis(pwFld)){
              fillEl(pwFld, entry.pw);
              filledFields.add(pwFld);
              showToast(esc(entry.site)+' — dono fields filled! ✓');
              pendingEntry=null;
              sessionStorage.removeItem('__bsrPending');
            }
          });
        }, 400);
        showToast(esc(entry.site)+' — ID fill, password page loading...');
        return;
      }

      if(pVis&&!uVis){
        // ── PAGE 2: Only password visible ──
        // Try pendingEntry first, then sessionStorage, then match by site
        let e2 = pendingEntry;
        if(!e2){try{const s=sessionStorage.getItem('__bsrPending');if(s)e2=JSON.parse(s);}catch(x){}}
        if(!e2){const m=getM();if(m.length===1)e2=m[0];}
        if(e2&&pEl){
          fillEl(pEl, e2.pw);
          filledFields.add(pEl);
          showToast(esc(e2.site)+' password filled! ✓');
          pendingEntry=null;
          sessionStorage.removeItem('__bsrPending');
        }
        return;
      }
    }

    // ── Normal single-page fill ──
    const u=findU(triggerEl);
    if(u&&u!==triggerEl){fillEl(u,entry.user);setTimeout(()=>fillEl(triggerEl,entry.pw),delay);}
    else if(triggerEl.type==='password'){fillEl(triggerEl,entry.pw);}
    else{fillEl(triggerEl,entry.user);const pw=findPw();if(pw)setTimeout(()=>fillEl(pw,entry.pw),delay);}
    filledFields.add(triggerEl);
    showToast(esc(entry.site)+' filled! ✓');
  }

  // ─────────────────────────────────────────────────────────────
  // SUGGESTIONS DROPDOWN — inline below the field
  // ─────────────────────────────────────────────────────────────
  const SUG_CSS=`
    #bsr-sug{position:fixed;z-index:2147483647;background:#202124;border-radius:0 0 8px 8px;overflow:hidden;box-shadow:0 4px 8px rgba(0,0,0,.5),0 8px 20px rgba(0,0,0,.4);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Google Sans",Roboto,sans-serif;animation:sgIn .08s ease-out}
    @keyframes sgIn{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:none}}
    .si{display:flex;align-items:center;gap:11px;padding:10px 14px;cursor:pointer;transition:background .08s;outline:none;user-select:none}
    .si:not(:last-child){border-bottom:1px solid #303134}
    .si.hov,.si:focus{background:#303134}
    .si.sel{background:#35363a;outline:2px solid #4285f4;outline-offset:-2px}
    .sav{width:30px;height:30px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-weight:500;font-size:13px;color:#fff}
    .sin{flex:1;min-width:0}
    .sn{font-size:13px;color:#e8eaed;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;line-height:1.4}
    .sd{font-size:10.5px;color:#9aa0a6;margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .sem{padding:12px 14px;color:#9aa0a6;font-size:12px;text-align:center}
    .sf{padding:8px 14px;border-top:1px solid #3c3d42;background:#292a2d;display:flex;align-items:center;gap:7px;cursor:pointer;transition:background .1s}
    .sf:hover{background:#303134}
    .sft{font-size:11.5px;color:#8ab4f8}
    .sfk{margin-left:auto;font-size:9px;color:#5f6368}
  `;
  const AVCOL=['#4285f4','#ea4335','#fbbc04','#34a853','#ff6d00','#46bdc6','#7c4dff','#e91e63'];
  function avC(n){let h=0;for(let i=0;i<(n||'').length;i++)h=(n.charCodeAt(i)+(h<<5)-h)|0;return AVCOL[Math.abs(h)%AVCOL.length];}

  let activeFld=null, sugIdx=-1, sugList=[];

  function showSug(field, query){
    closeSug();
    sugList=getM(query);
    if(!sugList.length&&!query)return;
    if(!document.getElementById('bsr-sug-css')){const s=document.createElement('style');s.id='bsr-sug-css';s.textContent=SUG_CSS;document.head.appendChild(s);}
    activeFld=field; sugIdx=-1;
    const rect=field.getBoundingClientRect();
    const sug=document.createElement('div');sug.id='bsr-sug';
    const w=Math.max(rect.width,240);

    function buildRows(list,q){
      if(!list.length)return'<div class="sem">No matching accounts</div>';
      return list.map((p,i)=>`<div class="si" tabindex="-1" data-i="${i}">
        <div class="sav" style="background:${avC(p.site||p.user)}">${(p.site||p.user||'?')[0].toUpperCase()}</div>
        <div class="sin">
          <div class="sn">${escHL(p.user,q)}</div>
          <div class="sd">${esc(p.site)}</div>
        </div>
      </div>`).join('');
    }

    sug.innerHTML=buildRows(sugList,query)+`<div class="sf" id="bsr-sf"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#8ab4f8" stroke-width="2.5" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><span class="sft">Manage passwords...</span><span class="sfk">↑↓ Enter Esc</span></div>`;

    // Position: below field, same width
    const maxH=Math.min(sugList.length*52+42, 280);
    const spaceBelow=window.innerHeight-rect.bottom;
    const showAbove=spaceBelow<maxH+10&&rect.top>maxH;
    if(showAbove){sug.style.cssText=`bottom:${window.innerHeight-rect.top}px;left:${rect.left}px;width:${w}px;border-radius:8px 8px 0 0;`;}
    else{sug.style.cssText=`top:${rect.bottom}px;left:${rect.left}px;width:${w}px;`;}
    document.body.appendChild(sug);

    // Hover effect
    sug.querySelectorAll('.si').forEach(item=>{
      item.addEventListener('mouseenter',()=>{sug.querySelectorAll('.si').forEach(x=>x.classList.remove('sel'));item.classList.add('sel');sugIdx=parseInt(item.dataset.i);});
      item.addEventListener('mouseleave',()=>{item.classList.remove('sel');});
    });

    // Click items
    sug.querySelectorAll('.si').forEach((item,i)=>{
      item.onmousedown=e=>{e.preventDefault();};  // prevent blur before click
      item.onclick=()=>{fillForm(field,sugList[i]);closeSug();field.blur();};
    });
    sug.querySelector('#bsr-sf').onmousedown=e=>e.preventDefault();
    sug.querySelector('#bsr-sf').onclick=()=>{chrome.runtime.sendMessage({type:'OPEN_POPUP'});closeSug();};

    // Keyboard nav
    sug._kfn=function(e){
      const its=[...sug.querySelectorAll('.si')];
      if(e.key==='Escape'){closeSug();field.blur();return;}
      if(e.key==='ArrowDown'){
        e.preventDefault();e.stopPropagation();
        sugIdx=Math.min(sugIdx+1,its.length-1);
        its.forEach(x=>x.classList.remove('sel'));
        its[sugIdx]?.classList.add('sel');
        // Scroll into view
        its[sugIdx]?.scrollIntoView({block:'nearest'});
        field.focus(); // keep focus on field for typing
        return;
      }
      if(e.key==='ArrowUp'){
        e.preventDefault();e.stopPropagation();
        sugIdx=Math.max(sugIdx-1,-1);
        its.forEach(x=>x.classList.remove('sel'));
        if(sugIdx>=0){its[sugIdx]?.classList.add('sel');its[sugIdx]?.scrollIntoView({block:'nearest'});}
        field.focus();
        return;
      }
      if((e.key==='Enter'||e.key==='Tab')&&sugIdx>=0){
        e.preventDefault();
        const entry=sugList[sugIdx];
        if(entry){fillForm(field,entry);closeSug();}
        return;
      }
    };
    document.addEventListener('keydown',sug._kfn,true);
  }

  function closeSug(){
    const s=document.getElementById('bsr-sug');
    if(s){if(s._kfn)document.removeEventListener('keydown',s._kfn,true);s.remove();}
    activeFld=null;sugIdx=-1;sugList=[];
  }

  function escHL(text,q){
    const s=esc(text||'');
    if(!q||!q.trim())return s;
    try{return s.replace(new RegExp('('+q.trim().replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','gi'),'<span style="color:#fff;font-weight:600">$1</span>');}catch(e){return s;}
  }

  // ─────────────────────────────────────────────────────────────
  // INJECT — password field button
  // ─────────────────────────────────────────────────────────────
  function injectPwBtn(pwEl){
    if(pwEl.dataset.bsr46p)return;pwEl.dataset.bsr46p='1';
    const wrap=pwEl.parentElement;if(!wrap)return;
    if(getComputedStyle(wrap).position==='static')wrap.style.position='relative';
    const btn=document.createElement('button');
    btn.type='button';btn.title='BSR Pro — AutoFill';
    btn.style.cssText='position:absolute;right:6px;top:50%;transform:translateY(-50%);width:22px;height:22px;border-radius:4px;border:none;cursor:pointer;background:#fff;display:flex;align-items:center;justify-content:center;z-index:2147483646;padding:0;opacity:.92;box-shadow:0 1px 3px rgba(0,0,0,.15),0 0 0 1px rgba(0,0,0,.08);transition:all .12s;';
    btn.innerHTML='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a73e8" stroke-width="2.2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>';
    btn.onmouseenter=()=>{btn.style.boxShadow='0 2px 6px rgba(0,0,0,.2),0 0 0 1px rgba(26,115,232,.4)';btn.style.opacity='1';};
    btn.onmouseleave=()=>{btn.style.boxShadow='0 1px 3px rgba(0,0,0,.15),0 0 0 1px rgba(0,0,0,.08)';btn.style.opacity='.92';};
    btn.onmousedown=e=>{e.preventDefault();e.stopPropagation();};
    btn.onclick=e=>{
      e.preventDefault();e.stopPropagation();
      const m=getM();
      if(!m.length){loadRetry=0;loadPw(()=>{const m2=getM();if(!m2.length)showToast('No passwords saved for this site');else if(m2.length===1)fillForm(pwEl,m2[0]);else showSug(pwEl,'');});}
      else if(m.length===1)fillForm(pwEl,m[0]);
      else showSug(pwEl,'');
    };
    wrap.appendChild(btn);
    const pr=parseInt(getComputedStyle(pwEl).paddingRight)||0;
    if(pr<36)pwEl.style.paddingRight='36px';
  }

  // ─────────────────────────────────────────────────────────────
  // ATTACH suggestions to username/email fields
  // ─────────────────────────────────────────────────────────────
  function attachSug(el){
    if(el.dataset.bsr46s)return;el.dataset.bsr46s='1';
    el.addEventListener('focus',()=>{if(passwords.length){const m=getM(el.value);if(m.length)showSug(el,el.value);}});
    el.addEventListener('input',()=>{const m=getM(el.value);if(m.length)showSug(el,el.value);else closeSug();});
    el.addEventListener('blur',()=>{setTimeout(()=>{const s=document.getElementById('bsr-sug');if(s&&document.activeElement&&s.contains(document.activeElement))return;closeSug();},250);});
  }

  // ─────────────────────────────────────────────────────────────
  // TOAST
  // ─────────────────────────────────────────────────────────────
  function showToast(msg){
    document.getElementById('bsr-toast')?.remove();
    const t=document.createElement('div');t.id='bsr-toast';
    t.style.cssText='position:fixed;bottom:16px;right:16px;z-index:2147483647;background:#202124;border-radius:8px;padding:9px 14px;color:#e8eaed;font-size:12.5px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;box-shadow:0 4px 8px rgba(0,0,0,.5);display:flex;align-items:center;gap:8px;animation:bTst .15s ease-out;max-width:280px;';
    if(!document.getElementById('bsr-ts')){const s=document.createElement('style');s.id='bsr-ts';s.textContent='@keyframes bTst{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}';document.head.appendChild(s);}
    const ic=document.createElement('span');ic.innerHTML='<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#34a853" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>';
    t.appendChild(ic);const sp=document.createElement('span');sp.textContent=msg;t.appendChild(sp);
    document.body.appendChild(t);
    setTimeout(()=>{t.style.transition='all .2s';t.style.opacity='0';t.style.transform='translateY(8px)';setTimeout(()=>t.remove(),200);},3000);
  }

  // ─────────────────────────────────────────────────────────────
  // SCAN
  // ─────────────────────────────────────────────────────────────
  function scanAndInject(){
    // Password fields → key button
    document.querySelectorAll(P_SEL.join(',')).forEach(el=>{if(vis(el))injectPwBtn(el);});

    // Username fields → inline suggestions
    const cfg=getCfg();
    const uSels=cfg?.u||U_SEL;
    uSels.forEach(s=>{try{document.querySelectorAll(s).forEach(el=>{if(vis(el))attachSug(el);});}catch(e){}});

    // ── Check if we're on page 2 (password page) with pending entry ──
    const stored=pendingEntry||(()=>{try{const s=sessionStorage.getItem('__bsrPending');return s?JSON.parse(s):null;}catch(x){return null;}})();
    if(stored){
      const cfg2=getCfg();
      const pSel=cfg2?.p?.[0]||'input[type="password"]';
      const uSel=cfg2?.u?.[0];
      const uEl=uSel?document.querySelector(uSel):null;
      const pEl=document.querySelector(pSel);
      if(pEl&&vis(pEl)&&(!uEl||!vis(uEl))){
        setTimeout(()=>{
          if(pEl&&vis(pEl)){
            fillEl(pEl,stored.pw);
            filledFields.add(pEl);
            showToast(esc(stored.site)+' password filled! ✓');
            pendingEntry=null;
            sessionStorage.removeItem('__bsrPending');
          }
        },400);
        return;
      }
    }

    if(scanDone||!passwords.length)return;
    const m=getM();if(!m.length)return;
    scanDone=true;
    const cfg3=getCfg();

    // 2-page auto-fill
    if(cfg3?.twoPage){
      const uEl=cfg3.u?document.querySelector(cfg3.u[0]):null;
      const pEl=cfg3.p?document.querySelector(cfg3.p[0]):null;
      if(uEl&&vis(uEl)&&(!pEl||!vis(pEl))){
        setTimeout(()=>{if(uEl&&vis(uEl)){if(m.length===1)fillForm(uEl,m[0]);else showSug(uEl,'');}},cfg3.delay||700);
        return;
      }
      if(pEl&&vis(pEl)&&(!uEl||!vis(uEl))){
        setTimeout(()=>{
          const st2=pendingEntry||(()=>{try{const s=sessionStorage.getItem('__bsrPending');return s?JSON.parse(s):null;}catch(x){return null;}})();
          if(st2){fillEl(pEl,st2.pw);filledFields.add(pEl);showToast(esc(st2.site)+' password filled! ✓');pendingEntry=null;sessionStorage.removeItem('__bsrPending');}
          else if(m.length===1){fillEl(pEl,m[0].pw);filledFields.add(pEl);}
          else showSug(pEl,'');
        },cfg3.delay||700);
        return;
      }
    }

    const pw=findPw();
    if(!pw||!vis(pw)||filledFields.has(pw))return;
    const isAng=!!(cfg3?.angular)||!!document.querySelector('[ng-version],[_nghost-]');
    const delay=isAng?1500:cfg3?800:400;
    if(m.length===1){setTimeout(()=>{if(vis(pw)&&!filledFields.has(pw))fillForm(pw,m[0]);},delay);}
    else{setTimeout(()=>{if(vis(pw))showSug(findU(pw)||pw,'');},delay+100);}
  }

  function scanShadow(root){try{const w=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT);let n;while(n=w.nextNode())if(n.shadowRoot){n.shadowRoot.querySelectorAll(P_SEL.join(',')).forEach(el=>{if(vis(el))injectPwBtn(el);});scanShadow(n.shadowRoot);}}catch(e){}}

  let st=null;
  const obs=new MutationObserver(()=>{clearTimeout(st);st=setTimeout(()=>{scanAndInject();scanShadow(document.body);},350);});

  function init(){
    loadPw(()=>{scanAndInject();scanShadow(document.body);obs.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['type','style','class','hidden','disabled']});});
  }

  let lastUrl=location.href;
  new MutationObserver(()=>{
    if(location.href!==lastUrl){
      lastUrl=location.href;scanDone=false;
      // Don't clear filledFields on URL change — keep for page 2 detection
      setTimeout(()=>{loadRetry=0;loadPw(scanAndInject);},500);
    }
  }).observe(document,{subtree:true,childList:true});

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);
  else init();

  function esc(s){return s?String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'):''; }
})();

// ─────────────────────────────────────────────────────────────
// PASSWORD SAVE PROMPT — detect login form submission
// ─────────────────────────────────────────────────────────────
(function(){
  if (window.__bsrSave50) return;
  window.__bsrSave50 = true;

  const SAVE_CSS = `
    #bsr-save{position:fixed;bottom:16px;right:16px;z-index:2147483647;
      width:300px;background:#202124;border-radius:10px;overflow:hidden;
      box-shadow:0 4px 12px rgba(0,0,0,.6),0 0 0 1px rgba(255,255,255,.07);
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
      animation:svIn .2s cubic-bezier(.34,1.4,.64,1);}
    @keyframes svIn{from{opacity:0;transform:translateY(20px) scale(.95)}to{opacity:1;transform:none}}
    .sv-hdr{padding:12px 14px 10px;border-bottom:1px solid #303134;display:flex;align-items:center;gap:9px;}
    .sv-logo{width:22px;height:22px;background:linear-gradient(135deg,#4285f4,#34a853);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
    .sv-title{font-size:12.5px;font-weight:600;color:#e8eaed;flex:1}
    .sv-x{background:none;border:none;cursor:pointer;color:#9aa0a6;padding:2px;border-radius:3px;display:flex;align-items:center}
    .sv-x:hover{color:#e8eaed;background:#303134}
    .sv-body{padding:10px 14px 12px}
    .sv-site{font-size:11px;color:#9aa0a6;margin-bottom:6px}
    .sv-row{display:flex;align-items:center;gap:8px;background:#2d2e32;border-radius:6px;padding:7px 10px;margin-bottom:5px}
    .sv-ic{color:#9aa0a6;display:flex;align-items:center;flex-shrink:0}
    .sv-val{font-size:12px;color:#e8eaed;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:inherit}
    .sv-dots{letter-spacing:2px;color:#9aa0a6}
    .sv-btns{display:flex;gap:8px;margin-top:10px}
    .sv-btn-save{flex:1;padding:8px;background:#4285f4;border:none;border-radius:6px;color:#fff;font-size:12px;font-weight:600;cursor:pointer;font-family:inherit;transition:background .15s}
    .sv-btn-save:hover{background:#5a95f5}
    .sv-btn-no{flex:1;padding:8px;background:#303134;border:none;border-radius:6px;color:#9aa0a6;font-size:12px;cursor:pointer;font-family:inherit;transition:background .15s}
    .sv-btn-no:hover{background:#3c3d42;color:#e8eaed}
    .sv-update{font-size:10px;color:#fbbc04;text-align:center;margin-top:6px}
  `;

  let saveTimer = null;

  function esc2(s){return s?String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'):''; }

  function showSavePrompt(user, pw, siteStr, isUpdate, existingId) {
    document.getElementById('bsr-save')?.remove();
    clearTimeout(saveTimer);

    if (!document.getElementById('bsr-save-css')) {
      const s=document.createElement('style');s.id='bsr-save-css';s.textContent=SAVE_CSS;document.head.appendChild(s);
    }

    const box = document.createElement('div'); box.id='bsr-save';
    box.innerHTML = `
      <div class="sv-hdr">
        <div class="sv-logo"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></div>
        <span class="sv-title">${isUpdate ? 'Update saved password?' : 'Save password?'}</span>
        <button class="sv-x" id="sv-x"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="sv-body">
        <div class="sv-site">${esc2(siteStr)}</div>
        <div class="sv-row">
          <span class="sv-ic"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span>
          <span class="sv-val">${esc2(user)}</span>
        </div>
        <div class="sv-row">
          <span class="sv-ic"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></span>
          <span class="sv-val sv-dots">••••••••</span>
        </div>
        ${isUpdate ? '<div class="sv-update">⚠️ Password changed — update karein?</div>' : ''}
        <div class="sv-btns">
          <button class="sv-btn-save" id="sv-yes">${isUpdate ? '🔄 Update' : '💾 Save'}</button>
          <button class="sv-btn-no" id="sv-no">Never</button>
        </div>
      </div>`;

    document.body.appendChild(box);

    // Auto-dismiss after 15s
    saveTimer = setTimeout(() => box.remove(), 15000);

    box.querySelector('#sv-x').onclick = () => { box.remove(); clearTimeout(saveTimer); };
    box.querySelector('#sv-no').onclick = () => { box.remove(); clearTimeout(saveTimer); };
    box.querySelector('#sv-yes').onclick = () => {
      chrome.runtime.sendMessage({
        type: 'SAVE_PASSWORD',
        entry: {
          id: existingId || (Date.now().toString(36)+Math.random().toString(36).slice(2,7)),
          site: siteStr, user, pw,
          url: location.href, cat: 'Other',
          notes: '', fav: false,
          created: new Date().toISOString(),
          updated: new Date().toISOString()
        }
      }, () => {
        box.innerHTML = `<div style="padding:14px 16px;display:flex;align-items:center;gap:10px;font-family:-apple-system,sans-serif"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34a853" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg><span style="color:#e8eaed;font-size:13px;font-weight:600">Password saved! ✓</span></div>`;
        setTimeout(() => box.remove(), 1800);
        clearTimeout(saveTimer);
      });
    };
  }

  // Detect form submission — capture username + password
  function detectAndPrompt() {
    const pFields = document.querySelectorAll('input[type="password"]');
    pFields.forEach(pwEl => {
      if (!pwEl.dataset.bsrSaveWatch) {
        pwEl.dataset.bsrSaveWatch = '1';
        const form = pwEl.closest('form') || document;

        // Watch form submit
        const doCheck = () => {
          const pw = pwEl.value; if (!pw || pw.length < 4) return;
          // Find username
          let user = '';
          for (const s of ['input[type="email"]','input[autocomplete="username"]','input[type="tel"]','input[name*="user" i]','input[name*="email" i]','input[name*="mobile" i]','input[id*="user" i]','input[type="text"]:not([readonly])']) {
            const el = (form===document?document:form).querySelector(s);
            if (el && el !== pwEl && el.value) { user=el.value; break; }
          }
          if (!user) user = location.hostname;

          // Check if already saved
          chrome.runtime.sendMessage({type:'GET_PASSWORDS'}, res => {
            if (chrome.runtime.lastError) return;
            const pws = res?.passwords || [];
            const existing = pws.find(p =>
              (p.user||'').toLowerCase() === user.toLowerCase() &&
              (p.site||'').toLowerCase().includes(location.hostname.replace(/^www\./,'').toLowerCase())
            );
            if (existing) {
              // Already saved — check if password changed
              if (existing.pw !== pw) showSavePrompt(user, pw, location.hostname, true, existing.id);
            } else {
              showSavePrompt(user, pw, location.hostname, false, null);
            }
          });
        };

        // Listen for form submit
        if (form !== document) {
          form.addEventListener('submit', () => setTimeout(doCheck, 100), {once:false});
        }

        // Also watch for button clicks near the form
        document.querySelectorAll('button[type="submit"],input[type="submit"],button:not([type])').forEach(btn => {
          if (!btn.dataset.bsrBtn) {
            btn.dataset.bsrBtn = '1';
            btn.addEventListener('click', () => setTimeout(doCheck, 300));
          }
        });

        // Watch Enter key in password field
        pwEl.addEventListener('keydown', e => { if (e.key==='Enter') setTimeout(doCheck,300); });
      }
    });
  }

  // Run detectAndPrompt when DOM changes
  const saveObs = new MutationObserver(() => detectAndPrompt());
  if (document.body) {
    detectAndPrompt();
    saveObs.observe(document.body, {childList:true, subtree:true});
  } else {
    document.addEventListener('DOMContentLoaded', () => { detectAndPrompt(); saveObs.observe(document.body,{childList:true,subtree:true}); });
  }
})();

// ─────────────────────────────────────────────────────────────
// OTP AUTO-FILL — jab OTP box aaye, saved code auto-fill karo
// ─────────────────────────────────────────────────────────────
(function(){
  if (window.__bsrOtp) return;
  window.__bsrOtp = true;

  // Firefox polyfill
  if (typeof browser !== 'undefined' && typeof chrome === 'undefined') globalThis.chrome = browser;

  // OTP field selectors — sab common patterns
  const OTP_SEL = [
    'input[autocomplete="one-time-code"]',
    'input[name*="otp" i]','input[id*="otp" i]',
    'input[name*="totp" i]','input[id*="totp" i]',
    'input[name*="token" i]','input[id*="token" i]',
    'input[name*="code" i]:not([name*="postal" i]):not([name*="zip" i]):not([name*="promo" i]):not([name*="coupon" i]):not([name*="invite" i])',
    'input[id*="code" i]:not([id*="postal" i]):not([id*="zip" i]):not([id*="promo" i]):not([id*="coupon" i])',
    'input[placeholder*="OTP" i]',
    'input[placeholder*="one time" i]',
    'input[placeholder*="authenticator" i]',
    'input[placeholder*="verification code" i]',
    'input[placeholder*="6-digit" i]',
    'input[placeholder*="6 digit" i]',
    'input[aria-label*="OTP" i]',
    'input[aria-label*="verification code" i]',
    'input[aria-label*="one-time" i]',
    // Numeric 6-char inputs — common OTP pattern
    'input[type="number"][maxlength="6"]',
    'input[type="text"][maxlength="6"][inputmode="numeric"]',
    'input[inputmode="numeric"][maxlength="6"]',
  ];

  // Base32 decode + HMAC-SHA1 (same as popup.js)
  function b32decode(s) {
    const A='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    s=s.replace(/=+$/,'').toUpperCase().replace(/[^A-Z2-7]/g,'');
    let bits=0,val=0; const out=[];
    for(const c of s){val=(val<<5)|A.indexOf(c);bits+=5;if(bits>=8){out.push((val>>>(bits-8))&255);bits-=8;}}
    return new Uint8Array(out);
  }

  async function hmacSha1(key,msg){
    const k=await crypto.subtle.importKey('raw',key,{name:'HMAC',hash:'SHA-1'},false,['sign']);
    return new Uint8Array(await crypto.subtle.sign('HMAC',k,msg));
  }

  async function genTOTP(secret,digits=6,period=30){
    const key=b32decode(secret);
    const counter=Math.floor(Date.now()/1000/period);
    const msg=new Uint8Array(8); let c=counter;
    for(let i=7;i>=0;i--){msg[i]=c&0xff;c>>>=8;}
    const h=await hmacSha1(key,msg);
    const offset=h[h.length-1]&0xf;
    const code=((h[offset]&0x7f)<<24|(h[offset+1]&0xff)<<16|(h[offset+2]&0xff)<<8|(h[offset+3]&0xff))%(10**digits);
    return String(code).padStart(digits,'0');
  }

  // Get OTP accounts from vault
  function getOtpAccounts(cb){
    try{
      chrome.runtime.sendMessage({type:'GET_PASSWORDS'},res=>{
        if(chrome.runtime.lastError){cb([]);return;}
        // V.otp is stored in vault separately — we get it via GET_OTP
        chrome.runtime.sendMessage({type:'GET_OTP'},res2=>{
          if(chrome.runtime.lastError){cb([]);return;}
          cb(res2?.otp||[]);
        });
      });
    }catch(e){cb([]);}
  }

  // Match OTP account for current site
  function matchOtp(otpList){
    const s=location.hostname.replace(/^www\./,'').toLowerCase();
    return otpList.filter(o=>{
      const os=(o.site||'').toLowerCase();
      return s.includes(os)||os.includes(s)||
             os.replace(/\.(com|in|org|net|io)$/,'').includes(s.replace(/\.(com|in|org|net|io)$/,''));
    });
  }

  // Fill OTP field
  function fillOtpField(el, code){
    if(!el||!code)return;
    el.focus();
    // React/Vue/Angular compatible
    const d=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value')||
             Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
    if(d?.set)d.set.call(el,code); else el.value=code;
    if(el._valueTracker)el._valueTracker.setValue('');
    [new Event('focus',{bubbles:true}),
     new InputEvent('input',{bubbles:true,composed:true,inputType:'insertText',data:code}),
     new Event('change',{bubbles:true}),
     new KeyboardEvent('keyup',{bubbles:true})
    ].forEach(e=>el.dispatchEvent(e));
    setTimeout(()=>el.dispatchEvent(new Event('blur',{bubbles:true})),80);
  }

  // Show OTP suggestion toast (small, near the field)
  const OTP_TOAST_CSS=`
    #bsr-otp-sug{
      position:fixed;z-index:2147483647;
      background:#202124;border-radius:8px;
      box-shadow:0 4px 12px rgba(0,0,0,.5),0 0 0 1px rgba(255,255,255,.07);
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
      animation:otpIn .15s ease-out;overflow:hidden;min-width:200px;
    }
    @keyframes otpIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:none}}
    .osu-hdr{padding:8px 12px 6px;display:flex;align-items:center;gap:8px;border-bottom:1px solid #303134}
    .osu-logo{width:18px;height:18px;background:linear-gradient(135deg,#4285f4,#34a853);border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
    .osu-title{font-size:11px;font-weight:600;color:#e8eaed;flex:1}
    .osu-x{background:none;border:none;cursor:pointer;color:#9aa0a6;padding:2px;border-radius:3px;display:flex;align-items:center}
    .osu-x:hover{color:#e8eaed}
    .osu-row{display:flex;align-items:center;gap:10px;padding:10px 12px;cursor:pointer;transition:background .08s}
    .osu-row:hover{background:#303134}
    .osu-code{font-family:monospace;font-size:20px;font-weight:700;letter-spacing:3px;color:#4285f4;flex:1}
    .osu-meta{text-align:right}
    .osu-site{font-size:10px;color:#9aa0a6}
    .osu-ring{display:block;margin:0 auto}
    .osu-fill{color:#34a853;font-size:10px;margin-top:2px;font-weight:600}
  `;

  let otpSugOpen=false;

  async function showOtpSuggestion(field, otpAccount){
    // Remove existing
    document.getElementById('bsr-otp-sug')?.remove();
    otpSugOpen=true;

    if(!document.getElementById('bsr-otp-css')){
      const s=document.createElement('style');s.id='bsr-otp-css';s.textContent=OTP_TOAST_CSS;document.head.appendChild(s);
    }

    const period=otpAccount.period||30;
    const remaining=()=>period-Math.floor(Date.now()/1000%period);

    // Generate code
    let code;
    try{ code=await genTOTP(otpAccount.secret, otpAccount.digits||6, period); }
    catch(e){ return; }

    const box=document.createElement('div'); box.id='bsr-otp-sug';

    box.innerHTML=`
      <div class="osu-hdr">
        <div class="osu-logo"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg></div>
        <span class="osu-title">BSR Pro — OTP</span>
        <button class="osu-x" id="otp-sug-x"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
      </div>
      <div class="osu-row" id="otp-sug-fill">
        <div>
          <div class="osu-code" id="otp-sug-code">${code.slice(0,3)} ${code.slice(3)}</div>
          <div class="osu-site">${escOtp(otpAccount.site)}</div>
        </div>
        <div class="osu-meta">
          <svg class="osu-ring" width="28" height="28" viewBox="0 0 36 36" style="transform:rotate(-90deg)">
            <circle cx="18" cy="18" r="14" fill="none" stroke="#303134" stroke-width="3"/>
            <circle id="otp-sug-ring" cx="18" cy="18" r="14" fill="none" stroke="#4285f4" stroke-width="3"
              stroke-dasharray="88" stroke-dashoffset="${88-(88*remaining()/period)}"
              stroke-linecap="round"/>
          </svg>
          <div class="osu-fill">Tap to fill</div>
        </div>
      </div>`;

    // Position below field
    const rect=field.getBoundingClientRect();
    const above=(window.innerHeight-rect.bottom)<130&&rect.top>130;
    box.style.cssText=`top:${above?Math.max(4,rect.top-130):Math.min(rect.bottom+4,window.innerHeight-140)}px;left:${Math.max(4,Math.min(rect.left,window.innerWidth-220))}px;`;
    document.body.appendChild(box);

    // Click to fill
    box.querySelector('#otp-sug-fill').onclick=()=>{
      fillOtpField(field,code);
      box.remove(); otpSugOpen=false;
      showOtpToast(escOtp(otpAccount.site)+' OTP filled!');
    };
    box.querySelector('#otp-sug-x').onclick=e=>{e.stopPropagation();box.remove();otpSugOpen=false;};

    // Live countdown
    const iv=setInterval(async()=>{
      if(!document.getElementById('bsr-otp-sug')){clearInterval(iv);return;}
      const rem=remaining();
      const ring=document.getElementById('otp-sug-ring');
      if(ring) ring.setAttribute('stroke-dashoffset',String(88-(88*rem/period)));
      // Refresh code at new period
      if(rem===period-1||rem===period){
        try{
          const newCode=await genTOTP(otpAccount.secret,otpAccount.digits||6,period);
          const cd=document.getElementById('otp-sug-code');
          if(cd) cd.textContent=newCode.slice(0,3)+' '+newCode.slice(3);
          code=newCode;
        }catch(e){}
      }
      // Color warning when <8s
      const ring2=document.getElementById('otp-sug-ring');
      if(ring2) ring2.setAttribute('stroke',rem<8?'#ea4335':'#4285f4');
    },1000);

    // Close on outside click
    setTimeout(()=>{
      function outside(e){
        const b=document.getElementById('bsr-otp-sug');
        if(b&&!b.contains(e.target)&&e.target!==field){b.remove();otpSugOpen=false;clearInterval(iv);document.removeEventListener('click',outside);}
      }
      document.addEventListener('click',outside);
    },200);
  }

  function showOtpToast(msg){
    document.getElementById('bsr-otp-t')?.remove();
    const t=document.createElement('div');t.id='bsr-otp-t';
    t.style.cssText='position:fixed;bottom:16px;right:16px;z-index:2147483647;background:#202124;border-radius:8px;padding:9px 14px;color:#34a853;font-size:12.5px;font-family:-apple-system,sans-serif;box-shadow:0 4px 8px rgba(0,0,0,.5);display:flex;align-items:center;gap:7px;animation:otpIn .15s ease-out;';
    t.innerHTML=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#34a853" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg><span>${msg}</span>`;
    document.body.appendChild(t);
    setTimeout(()=>{t.style.transition='all .2s';t.style.opacity='0';setTimeout(()=>t.remove(),200);},2500);
  }

  function escOtp(s){return s?String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'):''; }

  // Detect OTP fields and show suggestion
  let otpWatched=new WeakSet();

  function scanOtpFields(){
    chrome.runtime.sendMessage({type:'GET_OTP'},res=>{
      if(chrome.runtime.lastError)return;
      const otpList=res?.otp||[];
      if(!otpList.length)return;
      const matched=matchOtp(otpList);
      if(!matched.length)return;

      document.querySelectorAll(OTP_SEL.join(',')).forEach(el=>{
        if(otpWatched.has(el))return;
        otpWatched.add(el);

        // Show on focus
        el.addEventListener('focus',()=>{
          if(!otpSugOpen) showOtpSuggestion(el,matched[0]);
        });

        // Auto-show if already visible and empty
        if(!el.dataset.bsrOtp&&isOtpVisible(el)&&!el.value){
          el.dataset.bsrOtp='1';
          setTimeout(()=>{
            if(!el.value&&!otpSugOpen) showOtpSuggestion(el,matched[0]);
          },500);
        }
      });
    });
  }

  function isOtpVisible(el){
    if(!el)return false;
    try{const r=el.getBoundingClientRect(),s=getComputedStyle(el);return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'&&!el.disabled;}catch(e){return false;}
  }

  // Watch for OTP fields appearing (2FA pages load dynamically)
  let otpScanTimer=null;
  const otpObs=new MutationObserver(()=>{
    clearTimeout(otpScanTimer);
    otpScanTimer=setTimeout(scanOtpFields,400);
  });

  function initOtp(){
    scanOtpFields();
    if(document.body) otpObs.observe(document.body,{childList:true,subtree:true});
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',initOtp);
  else initOtp();
})();
