// Firefox/Safari polyfill — chrome API works in both
if (typeof browser !== 'undefined' && typeof chrome === 'undefined') {
  globalThis.chrome = browser;
}

// BabaSitaRam Pro v4 — Background Service Worker
const VAULTX_SIG = 'VaultX-Proprietary-v4';
const VAULTX_ORIGIN_HASH = '7a3f9b2e1c8d4f6b';
const APP_NAME = 'BabaSitaRam Pro';

// Keep-alive
chrome.alarms.create('bsr-ka', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(a => {
  if (a.name === 'bsr-ka') {
    chrome.storage.local.get('_ka', () => chrome.storage.local.set({ _ka: Date.now() }));
  }
  if (a.name === 'bsr-autolock') {
    // Store lock flag — popup reads this when it next opens
    chrome.storage.local.set({ _lockPending: true });
    // Try to notify if popup is currently open
    chrome.runtime.sendMessage({ type: 'DO_LOCK' }).catch(() => {});
    // Badge: show locked indicator
    chrome.action.setBadgeText({ text: '🔒' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
  }
});
self.addEventListener('activate', () => {
  chrome.alarms.get('bsr-ka', a => { if (!a) chrome.alarms.create('bsr-ka', { periodInMinutes: 0.4 }); });
});

function setBadge(count) {
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
}

function getVault(cb) {
  chrome.storage.local.get('vx4', d => {
    try { cb(d.vx4 ? JSON.parse(d.vx4) : { pw: [], bin: [] }); }
    catch (e) { cb({ pw: [], bin: [] }); }
  });
}

chrome.runtime.onStartup.addListener(() => getVault(V => setBadge((V.pw||[]).length)));

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'bsr-open', title: '🔐 BabaSitaRam Pro mein open karo', contexts: ['link'], targetUrlPatterns: ['*://*/*.vaultbak'] });
  getVault(V => setBadge((V.pw||[]).length));
});

chrome.contextMenus.onClicked.addListener(info => {
  if (info.menuItemId === 'bsr-open') chrome.tabs.create({ url: info.linkUrl });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'BADGE_UPDATE') { setBadge(msg.count); return; }

  if (msg.type === 'OPEN_POPUP') {
    chrome.action.openPopup().catch(()=>{});
    return;
  }

  if (msg.type === 'GET_PASSWORDS') {
    getVault(V => sendResponse({ passwords: V.pw || [] }));
    return true;
  }

  if (msg.type === 'VAULT_UNLOCKED') {
    // Broadcast passwords + otp to all tabs
    chrome.tabs.query({}, tabs => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'VAULT_UNLOCKED',
          passwords: msg.passwords || [],
          otp: msg.otp || []
        }).catch(() => {});
      });
    });
    return;
  }

  if (msg.type === 'VERIFY_VAULTBAK') {
    verifyOrigin(msg.content).then(sendResponse).catch(e => sendResponse({ ok: false, error: e.message }));
    return true;
  }

  if (msg.type === 'GET_OTP') {
    getVault(V => sendResponse({ otp: V.otp || [] }));
    return true;
  }

  if (msg.type === 'SAVE_PASSWORD') {
    getVault(V => {
      try {
        const i = (V.pw||[]).findIndex(p => p.id === msg.entry.id);
        if (i >= 0) V.pw[i] = msg.entry; else (V.pw = V.pw || []).push(msg.entry);
        chrome.storage.local.set({ vx4: JSON.stringify(V) });
        setBadge(V.pw.length);
        sendResponse({ ok: true });
      } catch (e) { sendResponse({ ok: false }); }
    });
    return true;
  }
});

async function verifyOrigin(content) {
  try {
    const obj = JSON.parse(content);
    if (obj.sig !== VAULTX_SIG) return { ok: false, error: '🚫 File is app ke liye nahi hai!' };
    if (!obj.originHash) return { ok: false, error: '🚫 Origin token missing' };
    const raw = JSON.stringify({ app: obj.app, version: obj.version });
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw + VAULTX_ORIGIN_HASH));
    const expected = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('').slice(0,32);
    if (obj.originHash !== expected) return { ok: false, error: '🚫 File tampered!' };
    return { ok: true };
  } catch (e) { return { ok: false, error: 'Invalid format' }; }
}
