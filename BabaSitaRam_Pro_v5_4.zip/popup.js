// BabaSitaRam Pro v4 — Popup JS
const VAULTX_SIG = 'VaultX-Proprietary-v4';
const VAULTX_ORIGIN_HASH = '7a3f9b2e1c8d4f6b';
const APP_NAME = 'BabaSitaRam Pro';

let V = { pw: [], master: '', settings: {}, bin: [], bioCredId: null, otp: [] };
let unlocked = false;
let autoLockTimer = null;
let currentSite = '';
let editingId = null;
let showFavOnly = false;
let clipTimer = null;
let pendingExportFmt = null;
const pwHideTimers = {};

// ── SVG icons (no emoji = less memory, crisper) ──
const IC = {
  user: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
  lock: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`,
  copy: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>`,
  eye: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
  eyeOff: `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>`,
  edit: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
  fill: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>`,
  star: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  starFill: `<svg width="11" height="11" viewBox="0 0 24 24" fill="#f59e0b" stroke="#f59e0b" stroke-width="1"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  trash: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>`,
  restore: `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.95"/></svg>`,
};

const CAT_EM = { Social:'💬', Banking:'🏦', Email:'📧', Work:'💼', Shopping:'🛒', Games:'🎮', Other:'📁' };
const CAT_CLS = { Social:'social', Banking:'banking', Email:'email', Work:'work', Shopping:'shopping', Games:'games', Other:'other' };

// ── Event delegation ──
document.addEventListener('click', e => {
  // Existing data-action delegation
  const btn = e.target.closest('[data-action]');
  if (btn) {
    const a = btn.dataset.action;
    const idx = btn.dataset.idx !== undefined ? parseInt(btn.dataset.idx) : undefined;
    if (a === 'cpEl')      cpEl(btn.dataset.el, btn.dataset.msg);
    else if (a === 'togShow')   togShow(btn.dataset.el, idx, btn);
    else if (a === 'cpPw')      cpPw(idx);
    else if (a === 'fillPage')  fillPage(idx);
    else if (a === 'editPw')    openModal(idx);
    else if (a === 'togFav')    toggleFav(idx);
    else if (a === 'restorePw') restorePw(idx);
    else if (a === 'permDel')   permDel(idx);
    return;
  }

  // Security tab — Fix buttons (openModal by password id)
  const fixBtn = e.target.closest('.sec-fix-btn');
  if (fixBtn) {
    const pid = fixBtn.dataset.pid;
    const idx = V.pw.findIndex(x => x.id === pid);
    if (idx >= 0) openModal(idx);
    return;
  }

  // Breach tab — Change buttons
  const bfixBtn = e.target.closest('.breach-fix-btn');
  if (bfixBtn) {
    const pid = bfixBtn.dataset.pid;
    const idx = V.pw.findIndex(x => x.id === pid);
    if (idx >= 0) openModal(idx);
    return;
  }

  // OTP — copy button
  const otpCp = e.target.closest('.otp-cp-btn');
  if (otpCp) { cpOtp(otpCp.dataset.oid); return; }

  // OTP — delete button
  const otpDel = e.target.closest('.otp-del-btn');
  if (otpDel) { delOtp(otpDel.dataset.oid); return; }

  // Breach check button
  if (e.target.closest('#breachCheckBtn')) { runBreachCheck(); return; }
});

document.addEventListener('DOMContentLoaded', async () => {
  await loadVault();
  getCurrentSite();

  // First-use hint
  if (!V.master) {
    const e = document.getElementById('lErr');
    e.textContent = 'First time: koi bhi Master Password set karein';
    e.style.display = 'block';
    e.style.color = 'var(--a2)';
    e.style.borderColor = 'rgba(6,182,212,.25)';
    e.style.background = 'rgba(6,182,212,.07)';
    document.getElementById('ulBtn').innerHTML = IC.fill + ' Setup & Unlock';
  }
  document.getElementById('mpI').focus();

  // Lock screen
  // Listen for DO_LOCK from background
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === 'DO_LOCK' && unlocked) {
      toast('⏰ Auto-locked!', 'wn', 2000);
      setTimeout(lockVault, 500);
    }
  });
  // Also check on open: was lock triggered while popup was closed?
  chrome.storage.local.get('_lockPending', d => {
    if (d._lockPending && unlocked) {
      chrome.storage.local.remove('_lockPending');
      lockVault();
    }
  });

  document.getElementById('mpI').addEventListener('keydown', e => { if (e.key === 'Enter') doUnlock(); });
  document.getElementById('ulBtn').addEventListener('click', doUnlock);
  document.getElementById('eyeMpI').addEventListener('click', function() { tvSvg('mpI', this); });
  document.getElementById('lockBtn').addEventListener('click', lockVault);
  document.getElementById('autoLockSel').addEventListener('change', function() { setAutoLock(parseInt(this.value)); });
  document.getElementById('bioBtn').addEventListener('click', doBioUnlock);
  initBioBtn();

  // Tabs
  document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', function() { goTab(this.dataset.tab, this); });
  });

  // Search
  document.getElementById('srchI').addEventListener('input', function() { renderAll(this.value); });

  // Import tab
  document.getElementById('eyeImpPw').addEventListener('click', function() { tvSvg('impPw', this); });
  // Toggle extra password field
  document.getElementById('diffPwBtn').addEventListener('click', function() {
    const extra = document.getElementById('impPwExtra');
    const isHidden = extra.style.display === 'none';
    extra.style.display = isHidden ? 'block' : 'none';
    this.textContent = isHidden ? 'Current Master Password use karo' : 'Backup ka password alag tha? Click karein';
    if (isHidden) document.getElementById('impPw').focus();
  });
  document.getElementById('selFileBtn').addEventListener('click', () => document.getElementById('fImp').click());
  document.getElementById('fImp').addEventListener('change', function() { handleImp(this); });
  document.querySelectorAll('.fmt-btn').forEach(btn => {
    btn.addEventListener('click', function() {
      document.querySelectorAll('.fmt-btn').forEach(b => b.classList.remove('on'));
      this.classList.add('on');
      const fmt = this.dataset.fmt;
      document.getElementById('fImp').accept = fmt === 'all' ? '.vaultbak,.json,.csv' : '.' + fmt;
      document.getElementById('impPwWrap').style.display = (fmt === 'json' || fmt === 'csv') ? 'none' : '';
    });
  });

  // Generator options
  document.querySelectorAll('.gen-opt').forEach(btn => {
    btn.addEventListener('click', function() {
      this.classList.toggle('on');
      doGen();
    });
  });

  // Generator
  document.getElementById('gOut').addEventListener('click', cpGen);
  document.getElementById('genBtn').addEventListener('click', doGen);
  document.getElementById('cpGenBtn').addEventListener('click', cpGen);
  document.getElementById('lenS').addEventListener('input', function() {
    document.getElementById('lenV').textContent = this.value;
    doGen();
  });

  // Vault tab
  document.getElementById('addBtn').addEventListener('click', () => openModal(null));
  document.getElementById('favFilter').addEventListener('click', function() {
    showFavOnly = !showFavOnly;
    this.classList.toggle('on', showFavOnly);
    renderAll(document.getElementById('srchI').value);
  });

  // Modal
  document.getElementById('modalClose').addEventListener('click', closeModal);
  document.getElementById('modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
  document.getElementById('eyeMPw').addEventListener('click', function() { tvSvg('mPw', this); });
  document.getElementById('modalSave').addEventListener('click', savePw);
  document.getElementById('modalDel').addEventListener('click', deletePw);

  // Export
  document.getElementById('expVbBtn').addEventListener('click', () => openExpModal('vaultbak'));
  document.getElementById('expJsonBtn').addEventListener('click', () => exportVault('json'));
  document.getElementById('expCsvBtn').addEventListener('click', () => exportVault('csv'));
  document.getElementById('expModalClose').addEventListener('click', () => { document.getElementById('expModal').style.display = 'none'; });
  document.getElementById('expModal').addEventListener('click', e => { if (e.target.id === 'expModal') document.getElementById('expModal').style.display = 'none'; });
  document.getElementById('eyeExpPw').addEventListener('click', function() { tvSvg('expPwI', this); });
  document.getElementById('expConfirmBtn').addEventListener('click', doExportVaultbak);
  document.getElementById('expPwI').addEventListener('keydown', e => { if (e.key === 'Enter') doExportVaultbak(); });

  // Bin
  document.getElementById('emptyBinBtn').addEventListener('click', emptyBin);

  // OTP tab
  document.getElementById('eyeOtpSecret')?.addEventListener('click', function() { tvSvg('otpSecret', this); });
  document.getElementById('addOtpBtn')?.addEventListener('click', addOtpAccount);

  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.key === 'g') { goTab('gen', document.querySelector('[data-tab="gen"]')); doGen(); }
    if (e.key === 'Escape') closeModal();
  });
});

// ── Vault persistence ──
async function loadVault() {
  return new Promise(resolve => {
    chrome.storage.local.get(['vx4','vx3'], data => {
      try {
        if (data.vx4) V = JSON.parse(data.vx4);
        else if (data.vx3) { V = JSON.parse(data.vx3); } // migrate from v3
      } catch (e) {}
      if (!V.bin) V.bin = [];
      resolve();
    });
  });
}

function saveVault(triggerBackup = true) {
  chrome.storage.local.set({ vx4: JSON.stringify(V) });
  chrome.runtime.sendMessage({ type: 'BADGE_UPDATE', count: V.pw.length }).catch(() => {});
  // Only auto-backup when passwords actually change (not on settings change)
  if (triggerBackup && V.pw.length) {
    clearTimeout(saveVault._ab);
    saveVault._ab = setTimeout(() => autoBackup(), 2000);
  }
}

// ── Auto-backup ──
let autoBackup_running = false;
async function autoBackup() {
  if (!V.master || !V.pw.length || autoBackup_running) return;
  autoBackup_running = true;
  try {
    const meta = { app: APP_NAME, version: '4', date: new Date().toISOString(), autoBackup: true };
    const originHash = await signOrigin({ app: meta.app, version: meta.version });
    const enc = await encData({ passwords: V.pw, bin: V.bin || [], meta }, V.master);
    const content = JSON.stringify({ app: APP_NAME, version: '4', sig: VAULTX_SIG, originHash, encrypted: true, vault_backup: true, autoBackup: true, savedAt: new Date().toISOString(), data: enc });
    const blob = new Blob([content], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url, filename: 'bsr-auto-backup.vaultbak', saveAs: false, conflictAction: 'overwrite' }, () => {
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    });
  } catch (e) {}
  finally { autoBackup_running = false; }
}

function getCurrentSite() {
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (tabs[0]?.url) {
      try {
        currentSite = new URL(tabs[0].url).hostname.replace('www.', '');
        document.getElementById('siteUrl').textContent = currentSite || 'Unknown';
      } catch (e) {
        document.getElementById('siteUrl').textContent = 'Unknown site';
      }
    }
  });
}

// ── Utils ──
function toast(msg, type = 'ok', dur = 2200) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.className = 'toast ' + type + ' show';
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), dur);
}

function esc(s) {
  return s ? String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') : '';
}

function tvSvg(id, btn) {
  const inp = document.getElementById(id);
  const isHidden = inp.type === 'password';
  inp.type = isHidden ? 'text' : 'password';
  btn.innerHTML = isHidden ? IC.eyeOff : IC.eye;
}

function cryptoRand(max) { return crypto.getRandomValues(new Uint32Array(1))[0] % max; }

// ── Crypto ──
async function hashPw(pw, salt = 'vx_4_salt') {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(pw + salt));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

async function deriveKey(pw, salt, it = 100000) {
  const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: it, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt','decrypt']);
}

async function decData(b64, pw) {
  const raw = Uint8Array.from(atob(b64.replace(/\s/g,'')), c => c.charCodeAt(0));
  const salt = raw.slice(0,16), iv = raw.slice(16,28), ct = raw.slice(28);
  // Try multiple salt/iteration combos for backward compat
  const iters = [100000, 600000, 10000, 1000, 1];
  const salts = ['vx_4_salt','vx_3_salt','vx_2_salt','vx_salt',''];
  const passVariants = [pw];
  for (let s of salts) passVariants.push(await hashPw(pw, s));
  for (let p of passVariants) {
    for (let it of iters) {
      try {
        const key = await deriveKey(p, salt, it);
        const dec = await crypto.subtle.decrypt({ name:'AES-GCM', iv }, key, ct);
        return JSON.parse(new TextDecoder().decode(dec));
      } catch (e) {}
    }
  }
  throw new Error('Wrong password or corrupted file');
}

async function verifyOriginLock(obj) {
  const sigs = [VAULTX_SIG, 'VaultX-Proprietary-v3']; // backward compat
  if (!sigs.includes(obj.sig)) throw new Error('🚫 File kisi aur app ke liye hai!');
  if (!obj.originHash) throw new Error('🚫 Origin token missing');
  const raw = JSON.stringify({ app: obj.app, version: obj.version });
  // Try both origin hashes for backward compat
  for (const h of ['7a3f9b2e1c8d4f6b','7a3f9b2e1c8d4f6a']) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw + h));
    const expected = Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('').slice(0,32);
    if (obj.originHash === expected) return;
  }
  throw new Error('🚫 File tampered!');
}

// ── Unlock ──
let failCount = 0;
let lockUntil = 0;

async function doUnlock() {
  const pw = document.getElementById('mpI').value;
  const errEl = document.getElementById('lErr');
  const btn = document.getElementById('ulBtn');
  if (!pw) { showErr('Password daalo!'); return; }

  const now = Date.now();
  if (now < lockUntil) {
    showErr(`⏳ ${Math.ceil((lockUntil-now)/1000)}s baad try karo`); return;
  }
  if (!V.master) {
    V.master = await hashPw(pw);
    saveVault(); enterApp(); return;
  }

  btn.disabled = true;
  btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" style="animation:spin 1s linear infinite"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg> Checking...';

  if (!document.getElementById('spin-style')) {
    const s = document.createElement('style');
    s.id = 'spin-style';
    s.textContent = '@keyframes spin{to{transform:rotate(360deg)}}';
    document.head.appendChild(s);
  }

  try {
    const salts = ['vx_4_salt','vx_3_salt','vx_2_salt','vx_salt',''];
    let ok = false;
    for (let s of salts) { if (await hashPw(pw, s) === V.master) { ok = true; break; } }
    if (ok) {
      failCount = 0; lockUntil = 0;
      enterApp();
    } else {
      failCount++;
      if (failCount >= 10) lockUntil = Date.now() + 5*60*1000;
      else if (failCount >= 5) lockUntil = Date.now() + 30*1000;
      else if (failCount >= 3) lockUntil = Date.now() + 5*1000;
      showErr(`Galat password (${failCount} try)`);
      document.getElementById('mpI').style.borderColor = 'var(--er)';
      setTimeout(() => document.getElementById('mpI').style.borderColor = '', 700);
    }
  } finally {
    btn.disabled = false;
    btn.innerHTML = IC.fill + ' Unlock';
  }
}

function showErr(msg) {
  const e = document.getElementById('lErr');
  e.textContent = msg; e.style.display = 'block';
  e.style.color = 'var(--er)'; e.style.borderColor = 'rgba(239,68,68,.2)'; e.style.background = 'rgba(239,68,68,.07)';
}

function enterApp() {
  unlocked = true;
  if (!V.bin) V.bin = [];
  document.getElementById('lockScreen').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  document.getElementById('lockBtn').style.display = 'flex';
  document.getElementById('autoLockSel').style.display = 'block';
  renderFill(); renderAll(); doGen(); updateBinBadge();
  // Clear lock badge and pending flag
  chrome.alarms.clear('bsr-autolock');
  chrome.storage.local.remove('_lockPending');
  chrome.action.setBadgeText({ text: String(V.pw.length||'') });
  chrome.action.setBadgeBackgroundColor({ color: '#3b82f6' });
  // Restore saved auto-lock setting
  const savedLock = V.settings?.autoLockMins || 0;
  if (savedLock > 0) {
    document.getElementById('autoLockSel').value = String(savedLock);
    setAutoLock(savedLock);
  }
  setTimeout(() => registerBio(), 1200);
  // ── Broadcast to all tabs so autofill activates immediately ──
  chrome.runtime.sendMessage({ type: 'VAULT_UNLOCKED', passwords: V.pw || [], otp: V.otp || [] }).catch(()=>{});
}

function lockVault() {
  unlocked = false;
  rawMaster = '';
  clearTimeout(autoLockTimer);
  chrome.alarms.clear('bsr-autolock');
  document.getElementById('lockScreen').style.display = 'block';
  document.getElementById('app').style.display = 'none';
  document.getElementById('lockBtn').style.display = 'none';
  document.getElementById('autoLockSel').style.display = 'none';
  document.getElementById('autoLockSel').value = '0';
  document.getElementById('mpI').value = '';
  document.getElementById('lErr').style.display = 'none';
  initBioBtn();
}

function setAutoLock(mins) {
  chrome.alarms.clear('bsr-autolock');
  clearTimeout(autoLockTimer); autoLockTimer = null;
  V.settings = V.settings || {};
  V.settings.autoLockMins = mins;
  saveVault(false); // false = don't trigger backup for settings change
  if (!mins || mins <= 0) return;
  // chrome.alarms works even when popup is closed
  chrome.alarms.create('bsr-autolock', { delayInMinutes: mins });
  // Local timer for when popup stays open
  autoLockTimer = setTimeout(() => { toast('⏰ Auto-locked!', 'wn', 2000); lockVault(); }, mins * 60000);
}

// ── Modal ──
function openModal(idx) {
  editingId = idx !== null ? V.pw[idx]?.id : null;
  const p = idx !== null ? V.pw[idx] : null;
  document.getElementById('modalTitle').textContent = p ? 'Edit Password' : 'Add Password';
  document.getElementById('mSite').value = p?.site || '';
  document.getElementById('mUser').value = p?.user || '';
  document.getElementById('mPw').value = p?.pw || '';
  document.getElementById('mUrl').value = p?.url || '';
  document.getElementById('mCat').value = p?.cat || 'Other';
  document.getElementById('mNotes').value = p?.notes || '';
  document.getElementById('mFav').checked = p?.fav || false;
  document.getElementById('modalDel').style.display = p ? '' : 'none';
  document.getElementById('modal').style.display = 'flex';
  setTimeout(() => document.getElementById('mSite').focus(), 50);
}

function closeModal() {
  document.getElementById('modal').style.display = 'none';
  editingId = null;
}

function savePw() {
  const site = document.getElementById('mSite').value.trim();
  const user = document.getElementById('mUser').value.trim();
  const pw   = document.getElementById('mPw').value;
  if (!site || !user || !pw) { toast('Site, User, aur Password zaroori hai!', 'er'); return; }
  const entry = {
    id: editingId || uid(), site, user, pw,
    url: document.getElementById('mUrl').value.trim(),
    cat: document.getElementById('mCat').value,
    notes: document.getElementById('mNotes').value.trim(),
    fav: document.getElementById('mFav').checked,
    created: editingId ? (V.pw.find(p => p.id === editingId)?.created || new Date().toISOString()) : new Date().toISOString(),
    updated: new Date().toISOString()
  };
  if (editingId) {
    const i = V.pw.findIndex(p => p.id === editingId);
    if (i >= 0) V.pw[i] = entry;
  } else {
    V.pw.push(entry);
  }
  saveVault();
  renderAll(document.getElementById('srchI').value);
  renderFill();
  closeModal();
  toast(editingId ? '✓ Updated!' : '✓ Password saved!');
}

function deletePw() {
  if (!editingId) return;
  if (!confirm('Delete? Recycle Bin mein jayega.')) return;
  const i = V.pw.findIndex(p => p.id === editingId);
  if (i >= 0) {
    if (!V.bin) V.bin = [];
    V.bin.unshift({ ...V.pw[i], deletedAt: new Date().toISOString() });
    V.pw.splice(i, 1);
  }
  saveVault(); renderAll(); renderFill(); updateBinBadge(); closeModal();
  toast('Moved to Bin', 'wn');
}

function toggleFav(idx) {
  V.pw[idx].fav = !V.pw[idx].fav;
  saveVault();
  renderAll(document.getElementById('srchI').value);
  renderFill();
}

// ── Bin ──
function renderBin() {
  if (!V.bin) V.bin = [];
  const g = document.getElementById('binList');
  if (!V.bin.length) {
    g.innerHTML = `<div class="empty"><div class="empty-ic" style="opacity:.3">${IC.trash}</div><div class="empty-t">Bin khaali hai</div></div>`;
    return;
  }
  g.innerHTML = V.bin.map((p, i) => {
    const daysAgo = Math.floor((Date.now() - new Date(p.deletedAt)) / 86400000);
    const ct = CAT_CLS[p.cat] || 'other';
    return `<div class="bin-card">
      <div class="pwc-av av-${ct}" style="width:32px;height:32px;border-radius:8px;font-size:14px">${CAT_EM[p.cat]||'📁'}</div>
      <div class="bin-info">
        <div class="bin-site">${esc(p.site)}</div>
        <div class="bin-user">${esc(p.user)}</div>
        <div class="bin-days">${daysAgo}d ago</div>
      </div>
      <div class="bin-acts">
        <button class="btn btn-ok ca-btn" data-action="restorePw" data-idx="${i}" style="gap:4px">${IC.restore} Restore</button>
        <button class="btn btn-danger ca-btn del" data-action="permDel" data-idx="${i}" style="gap:4px">${IC.trash} Delete</button>
      </div>
    </div>`;
  }).join('');
}

function restorePw(idx) {
  if (!V.bin) return;
  const entry = { ...V.bin[idx] }; delete entry.deletedAt;
  V.pw.push(entry); V.bin.splice(idx, 1);
  saveVault(); renderBin(); renderAll(); renderFill(); updateBinBadge();
  toast('↩ Restored!');
}

function permDel(idx) {
  if (!V.bin) return;
  if (!confirm('Permanently delete? Wapas nahi aayega!')) return;
  V.bin.splice(idx, 1);
  saveVault(); renderBin(); updateBinBadge();
  toast('Permanently deleted', 'er');
}

function emptyBin() {
  if (!V.bin?.length) { toast('Bin already khaali', 'wn'); return; }
  if (!confirm(`${V.bin.length} passwords permanently delete honge!`)) return;
  V.bin = []; saveVault(); renderBin(); updateBinBadge();
  toast('Bin cleared', 'wn');
}

function updateBinBadge() {
  const tab = document.querySelector('[data-tab="bin"]');
  if (!tab) return;
  const count = V.bin?.length || 0;
  // Keep SVG icon, just update text node after it
  const texts = [...tab.childNodes].filter(n => n.nodeType === 3);
  texts.forEach(n => n.remove());
  tab.appendChild(document.createTextNode(count > 0 ? ` Bin(${count})` : ' Bin'));
}

// ── Password Card ──
function strSc(pw) {
  if (!pw) return { s:0, l:'', c:'#ef4444', lv:0 };
  let sc = 0;
  if (pw.length >= 8) sc++; if (pw.length >= 12) sc++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) sc++;
  if (/[0-9]/.test(pw)) sc++;
  if (/[^a-zA-Z0-9]/.test(pw)) sc++;
  const lv = Math.min(3, Math.floor(sc*3/5));
  return { s:lv+1, l:['Weak','Fair','Good','Strong'][lv], c:['#ef4444','#f59e0b','#3b82f6','#10b981'][lv], lv };
}

function pwCard(p, showFill = false) {
  const { l, c } = strSc(p.pw);
  const ct = CAT_CLS[p.cat] || 'other';
  const em = CAT_EM[p.cat] || '📁';
  const idx = V.pw.findIndex(x => x.id === p.id);
  return `<div class="pwc">
    <div class="pwc-top">
      <div class="pwc-av av-${ct}">${em}</div>
      <div class="pwc-name">${esc(p.site)}</div>
      <span class="pwc-cat cat-${ct}">${esc(p.cat)}</span>
    </div>
    <div class="pwc-row">
      <span class="pwc-lbl" style="color:var(--t4)">${IC.user}</span>
      <span class="pwc-val" id="eu_${idx}">${esc(p.user)}</span>
      <button class="ic-btn" data-action="cpEl" data-el="eu_${idx}" data-msg="Username copied" title="Copy">${IC.copy}</button>
    </div>
    <div class="pwc-row">
      <span class="pwc-lbl" style="color:var(--t4)">${IC.lock}</span>
      <span class="pwc-val hide" id="ep_${idx}">••••••••••</span>
      <button class="ic-btn" data-action="togShow" data-el="ep_${idx}" data-idx="${idx}" title="Show/Hide">${IC.eye}</button>
      <button class="ic-btn" data-action="cpPw" data-idx="${idx}" title="Copy password">${IC.copy}</button>
    </div>
    <div class="str-bar"><div class="str-fill" style="width:${strSc(p.pw).s*20}%;background:${c}"></div></div>
    <div class="str-lbl" style="color:${c}">${l}</div>
    ${p.notes ? `<div class="pwc-notes">${esc(p.notes)}</div>` : ''}
    <div class="card-acts">
      <button class="ca-btn ${p.fav ? 'fav-on' : ''}" data-action="togFav" data-idx="${idx}">
        ${p.fav ? IC.starFill : IC.star} Fav
      </button>
      <button class="ca-btn" data-action="editPw" data-idx="${idx}">${IC.edit} Edit</button>
      ${showFill ? `<button class="ca-btn fill-ca" data-action="fillPage" data-idx="${idx}">${IC.fill} Fill</button>` : ''}
    </div>
  </div>`;
}

// ── AutoFill tab ──
function renderFill() {
  const g = document.getElementById('fillList');
  if (!currentSite) { g.innerHTML = emptyState('🌐', 'Site detect nahi hui', ''); return; }
  const matches = V.pw.filter(p =>
    p.site.toLowerCase().includes(currentSite) || currentSite.includes(p.site.toLowerCase()) ||
    (p.url && p.url.includes(currentSite))
  );
  g.innerHTML = matches.length
    ? matches.map(p => pwCard(p, true)).join('')
    : emptyState('🔍', `${esc(currentSite)} ke liye koi password nahi`, 'Vault tab mein add karein');
}

// ── Vault tab ──
function renderAll(q = '') {
  const g = document.getElementById('allList');
  let pws = [...V.pw];
  if (showFavOnly) pws = pws.filter(p => p.fav);
  if (q) { const ql = q.toLowerCase(); pws = pws.filter(p => p.site.toLowerCase().includes(ql) || p.user.toLowerCase().includes(ql)); }
  pws.sort((a,b) => (b.fav?1:0)-(a.fav?1:0) || a.site.localeCompare(b.site));
  g.innerHTML = pws.length
    ? pws.map(p => pwCard(p, false)).join('')
    : emptyState('🔒', showFavOnly ? 'Koi favorite nahi' : 'Vault khaali hai', showFavOnly ? '' : 'Add New se pehla password add karein');
}

function emptyState(ic, title, sub) {
  return `<div class="empty"><div class="empty-ic">${ic}</div><div class="empty-t">${title}</div>${sub?`<div class="empty-s">${sub}</div>`:''}</div>`;
}

// ── Card interactions ──
function togShow(elId, idx, btn) {
  const el = document.getElementById(elId);
  if (!el) return;
  if (el.classList.contains('hide')) {
    el.textContent = V.pw[idx].pw;
    el.classList.remove('hide');
    btn.innerHTML = IC.eyeOff;
    clearTimeout(pwHideTimers[idx]);
    pwHideTimers[idx] = setTimeout(() => {
      el.textContent = '••••••••••'; el.classList.add('hide');
      btn.innerHTML = IC.eye;
    }, 15000);
  } else {
    clearTimeout(pwHideTimers[idx]);
    el.textContent = '••••••••••'; el.classList.add('hide');
    btn.innerHTML = IC.eye;
  }
}

function cpEl(elId, msg) {
  const el = document.getElementById(elId);
  if (!el) return;
  navigator.clipboard.writeText(el.textContent).then(() => toast('✓ ' + msg));
}

function cpPw(idx) {
  navigator.clipboard.writeText(V.pw[idx].pw).then(() => {
    toast('✓ Password copied (30s mein clear)');
    clearTimeout(clipTimer);
    clipTimer = setTimeout(() => navigator.clipboard.writeText(''), 30000);
  });
}

function fillPage(idx) {
  const p = V.pw[idx];
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: (user, pw) => {
        function setVal(el, v) {
          const proto = Object.getPrototypeOf(el);
          const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
          if (desc?.set) desc.set.call(el, v); else el.value = v;
          if (el._valueTracker) el._valueTracker.setValue('');
          ['focus','input','change','blur'].forEach(ev => el.dispatchEvent(new Event(ev, { bubbles: true })));
          el.dispatchEvent(new InputEvent('input', { bubbles: true, data: v }));
        }
        const pwF = document.querySelector('input[type="password"]');
        if (pwF) {
          const form = pwF.closest('form') || document;
          const uF = form.querySelector('input[type="email"],input[autocomplete="username"],input[type="text"]:not([readonly]),input[name*="user" i],input[name*="email" i]');
          if (uF && uF !== pwF) { setVal(uF, user); setTimeout(() => setVal(pwF, pw), 80); }
          else setVal(pwF, pw);
        }
      },
      args: [p.user, p.pw]
    });
    toast('✓ ' + p.site + ' filled!');
  });
}

// ── Tabs ──
function goTab(name, el) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('on'));
  document.querySelectorAll('.pg').forEach(p => p.classList.remove('on'));
  el.classList.add('on');
  document.getElementById('pg' + name.charAt(0).toUpperCase() + name.slice(1)).classList.add('on');
  if (name === 'fill') renderFill();
  if (name === 'all') renderAll();
  if (name === 'gen') doGen();
  if (name === 'bin') renderBin();
  if (name === 'sec') renderSec();
  if (name === 'otp') renderOtp();
}

// ── Generator ──
function doGen() {
  const len = parseInt(document.getElementById('lenS').value);
  const opts = {};
  document.querySelectorAll('.gen-opt.on').forEach(b => opts[b.dataset.opt] = true);
  let chars = '';
  if (opts.upper) chars += 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  if (opts.lower) chars += 'abcdefghjkmnpqrstuvwxyz';
  if (opts.nums)  chars += '23456789';
  if (opts.sym)   chars += '!@#$%^&*-_+=';
  if (!chars) chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let pw = '';
  for (let i = 0; i < len; i++) pw += chars[cryptoRand(chars.length)];
  const o = document.getElementById('gOut');
  o.textContent = pw;
  o.style.color = strSc(pw).c;
}

function cpGen() {
  const pw = document.getElementById('gOut').textContent;
  if (!pw || pw === 'Click Generate!') return;
  navigator.clipboard.writeText(pw).then(() => toast('✓ Copied!'));
}

function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }

// ── Biometric ──
function bioSupported() { return !!(window.PublicKeyCredential && navigator.credentials); }

async function initBioBtn() {
  const btn = document.getElementById('bioBtn');
  const hint = document.getElementById('bioHint');
  if (!bioSupported()) {
    hint.textContent = 'Biometric is device mein supported nahi';
    return;
  }
  if (V.bioCredId) {
    btn.style.display = 'flex';
    btn.style.marginTop = '8px';
    hint.textContent = 'Fingerprint / Face se seedha unlock karein';
    // Auto-trigger biometric after short delay — user doesn't have to click
    setTimeout(() => {
      if (!unlocked && V.bioCredId) doBioUnlock();
    }, 600);
  } else if (V.master) {
    hint.textContent = 'Unlock karein — phir biometric auto-setup ho jayega';
  }
}

async function registerBio() {
  if (!bioSupported() || V.bioCredId) return;
  try {
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const userId = new TextEncoder().encode(V.master.slice(0,16).padEnd(16,'0'));
    const cred = await navigator.credentials.create({
      publicKey: {
        challenge,
        rp: { name: APP_NAME, id: location.hostname || 'localhost' },
        user: { id: userId, name: 'vault-user', displayName: 'BabaSitaRam User' },
        pubKeyCredParams: [{ type:'public-key', alg:-7 },{ type:'public-key', alg:-257 }],
        authenticatorSelection: { authenticatorAttachment:'platform', userVerification:'required', requireResidentKey:false },
        timeout: 60000, attestation: 'none'
      }
    });
    V.bioCredId = btoa(String.fromCharCode(...new Uint8Array(cred.rawId)));
    saveVault();
    document.getElementById('bioBtn').style.display = 'flex';
    document.getElementById('bioHint').textContent = 'Biometric registered! Agli baar fingerprint se unlock hoga';
    toast('Biometric setup ho gaya!');
  } catch (e) { if (e.name !== 'NotAllowedError') {} }
}

async function doBioUnlock() {
  if (!bioSupported() || !V.bioCredId) return;
  const btn = document.getElementById('bioBtn');
  btn.disabled = true; btn.textContent = 'Verifying...';
  try {
    const challenge = crypto.getRandomValues(new Uint8Array(32));
    const rawId = Uint8Array.from(atob(V.bioCredId), c => c.charCodeAt(0));
    const assertion = await navigator.credentials.get({
      publicKey: { challenge, allowCredentials: [{ type:'public-key', id:rawId, transports:['internal'] }], userVerification:'required', timeout:60000 }
    });
    if (assertion) { failCount = 0; lockUntil = 0; enterApp(); toast('Biometric unlock!'); }
  } catch (e) {
    showErr(e.name === 'NotAllowedError' ? 'Biometric cancelled. Master Password use karein.' : 'Biometric error: ' + e.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> Fingerprint / Face Unlock`;
  }
}

// ── Import/Export ──
async function handleImp(input) {
  const file = input.files[0]; if (!file) return;
  // Auto-use current master password — user doesn't need to type it again
  const extraShown = document.getElementById('impPwExtra')?.style.display !== 'none';
  const impPwEl = document.getElementById('impPw');
  const pw = extraShown && impPwEl?.value ? impPwEl.value : V.master;
  const warn = document.getElementById('impWarn');
  const result = document.getElementById('impResult');
  warn.style.display = 'none'; result.style.display = 'none';

  try {
    const text = await file.text();
    const ext = file.name.split('.').pop().toLowerCase();
    let passwords = [];
    if (ext === 'vaultbak') passwords = await parseVB(text, pw);
    else if (ext === 'json') passwords = parseJ(text);
    else if (ext === 'csv') passwords = parseC(text);
    else {
      try { passwords = await parseVB(text, pw); }
      catch { try { passwords = parseJ(text); } catch { passwords = parseC(text); } }
    }
    if (!passwords.length) throw new Error('Koi password nahi mila');
    const existing = new Set(V.pw.map(p => p.id));
    let added = 0;
    passwords.forEach(p => { if (!existing.has(p.id)) { V.pw.push(p); added++; } });
    saveVault(); renderAll(); renderFill();
    result.textContent = `✓ ${added} passwords imported! (${passwords.length} total)`;
    result.style.display = 'block';
    toast(`✓ ${added} imported!`);
  } catch (e) {
    warn.textContent = e.message; warn.style.display = 'block';
  }
  input.value = '';
}

async function parseVB(text, pw) {
  let obj; try { obj = JSON.parse(text); } catch { throw new Error('Invalid file format'); }
  if ((obj.encrypted || obj.vault_backup) && obj.data) {
    if (obj.sig || obj.originHash) await verifyOriginLock(obj);
    // Always try V.master as fallback
    const decPw = pw || V.master;
    if (!decPw) throw new Error('Master Password se unlock karein pehle');
    const dec = await decData(obj.data, decPw);
    const list = findList(dec);
    if (!list) throw new Error('Decrypted data mein koi password nahi');
    return list.map(normP);
  }
  const list = findList(obj);
  if (!list) throw new Error('Unknown backup format');
  return list.map(normP);
}

function parseJ(text) {
  const obj = JSON.parse(text);
  if (obj.items) return obj.items.filter(i => i.type === 1).map(i => normP({ site: i.name, user: i.login?.username, pw: i.login?.password, url: i.login?.uris?.[0]?.uri, notes: i.notes, fav: i.favorite }));
  if (obj.passwords) return obj.passwords.map(normP);
  if (Array.isArray(obj)) return obj.map(normP);
  const list = findList(obj);
  if (list) return list.map(normP);
  throw new Error('Unknown JSON format');
}

function parseC(text) {
  const lines = text.split('\n').filter(l => l.trim());
  if (lines.length < 2) throw new Error('Empty CSV');
  const hdr = lines[0].toLowerCase().replace(/"/g,'').split(',');
  const fi = keys => keys.reduce((f,k) => { const i = hdr.findIndex(h => h.includes(k)); return i >= 0 ? i : f; }, -1);
  const si=fi(['name','title','site']), ui=fi(['username','user','email','login']), pi=fi(['password','pass']), uri=fi(['url','uri']), ni=fi(['notes','note']);
  const res = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = csvLine(lines[i]); if (!cols.length) continue;
    const site=cols[si>=0?si:0]||'', user=cols[ui>=0?ui:2]||'', pw=cols[pi>=0?pi:3]||'';
    if (!site&&!user&&!pw) continue;
    res.push(normP({ site, user, pw, url: uri>=0?cols[uri]:'', notes: ni>=0?cols[ni]:'' }));
  }
  return res;
}

function findList(o) {
  if (!o||typeof o!=='object') return null;
  if (Array.isArray(o)&&o.length) return o;
  for (let k of ['passwords','items','entries','data','list','vault']) { if (o[k]&&Array.isArray(o[k])&&o[k].length) return o[k]; }
  return null;
}

function normP(p) {
  return { id:p.id||uid(), site:p.site||p.name||p.title||'', user:p.user||p.username||p.email||p.login||'', pw:p.pw||p.password||p.pass||'', url:p.url||p.uri||'', cat:p.cat||p.category||'Other', notes:p.notes||p.note||'', fav:p.fav||p.favorite||false, created:p.created||new Date().toISOString(), updated:p.updated||new Date().toISOString() };
}

function csvLine(line) {
  const r=[]; let c='', inQ=false;
  for (let i=0; i<line.length; i++) {
    const ch=line[i];
    if (ch==='"') { if (inQ&&line[i+1]==='"') { c+='"'; i++; } else inQ=!inQ; }
    else if (ch===','&&!inQ) { r.push(c.trim()); c=''; }
    else c+=ch;
  }
  r.push(c.trim()); return r;
}

function openExpModal(fmt) {
  if (!V.pw.length) { toast('Koi password nahi!', 'er'); return; }
  pendingExportFmt = fmt;
  document.getElementById('expPwI').value = '';
  document.getElementById('expModal').style.display = 'flex';
  setTimeout(() => document.getElementById('expPwI').focus(), 50);
}

async function doExportVaultbak() {
  const pw = document.getElementById('expPwI').value;
  if (!pw) { toast('Password daalo!', 'er'); return; }
  const salts = ['vx_4_salt','vx_3_salt','vx_2_salt','vx_salt',''];
  let ok = false;
  for (let s of salts) { if (await hashPw(pw, s) === V.master) { ok = true; break; } }
  if (!ok) { toast('Galat Master Password!', 'er'); return; }
  document.getElementById('expModal').style.display = 'none';
  toast('Encrypting...', 'ok');
  try {
    const meta = { app: APP_NAME, version: '4', date: new Date().toISOString() };
    const originHash = await signOrigin({ app: meta.app, version: meta.version });
    const enc = await encData({ passwords: V.pw, meta }, pw);
    const content = JSON.stringify({ app: APP_NAME, version: '4', sig: VAULTX_SIG, originHash, encrypted: true, vault_backup: true, data: enc });
    dlFile(content, 'bsr-backup-' + new Date().toISOString().slice(0,10) + '.vaultbak', 'application/octet-stream');
    toast('.vaultbak exported!');
  } catch (e) { toast('Encryption failed: ' + e.message, 'er'); }
}

async function exportVault(fmt) {
  if (!V.pw.length) { toast('Koi password nahi!', 'er'); return; }
  if (fmt === 'json') {
    dlFile(JSON.stringify({ app: APP_NAME, version: '4', exported: new Date().toISOString(), passwords: V.pw }, null, 2), 'bsr-export-' + new Date().toISOString().slice(0,10) + '.json', 'application/json');
    toast('.json exported!');
  } else if (fmt === 'csv') {
    const hdr = 'name,url,username,password,notes,category\n';
    const rows = V.pw.map(p => `"${esc2(p.site)}","${esc2(p.url)}","${esc2(p.user)}","${esc2(p.pw)}","${esc2(p.notes)}","${esc2(p.cat)}"`).join('\n');
    dlFile(hdr + rows, 'bsr-export-' + new Date().toISOString().slice(0,10) + '.csv', 'text/csv');
    toast('.csv exported!');
  }
}

function dlFile(content, name, mime) {
  try {
    const blob = new Blob([content], { type: name.endsWith('.vaultbak') ? 'application/octet-stream' : mime });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({ url, filename: name, saveAs: false, conflictAction: 'uniquify' }, () => {
      if (chrome.runtime.lastError) {
        const a = document.createElement('a'); a.href = url; a.download = name;
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
      }
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    });
  } catch (e) { toast('Download failed: ' + e.message, 'er'); }
}

function esc2(s) { return s ? String(s).replace(/"/g,'""') : ''; }

async function signOrigin(data) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(data) + VAULTX_ORIGIN_HASH));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('').slice(0,32);
}


// ═══ SECURITY HEALTH ═══
function renderSec() {
  const g = document.getElementById('secContent');
  if (!g) return;
  if (!V.pw.length) {
    g.innerHTML = '<div class="empty"><div class="empty-ic" style="font-size:2rem">🛡️</div><div class="empty-t">Koi password nahi</div></div>';
    return;
  }

  // Analysis
  const now = Date.now();
  const pwCounts = {};
  let weak=[], reused=[], old90=[], noUrl=[], total=V.pw.length;

  V.pw.forEach(p => {
    // Weak
    const {lv} = strSc(p.pw);
    if (lv < 2) weak.push(p);
    // Reuse tracking
    const key = p.pw;
    if (!pwCounts[key]) pwCounts[key] = [];
    pwCounts[key].push(p);
    // Old (>90 days)
    const upd = p.updated || p.created;
    if (upd && (now - new Date(upd).getTime()) > 90*24*60*60*1000) old90.push(p);
    // No URL
    if (!p.url) noUrl.push(p);
  });

  const reusedList = Object.values(pwCounts).filter(g=>g.length>1).flat();
  const score = Math.max(0, 100 - weak.length*15 - reusedList.length*10 - old90.length*5);
  const scoreColor = score>=80?'#10b981':score>=60?'#f59e0b':'#ef4444';
  const scoreLabel = score>=80?'Good 🟢':score>=60?'Fair 🟡':'Weak 🔴';

  function issueList(arr, icon, label, action) {
    if (!arr.length) return `<div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.2);border-radius:7px;margin-bottom:7px;font-size:11px;color:var(--ok)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>${label} — sab theek hai!</div>`;
    return `<div style="background:var(--s2);border:1px solid var(--border2);border-radius:8px;margin-bottom:8px;overflow:hidden">
      <div style="padding:8px 12px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border)">
        <span style="font-size:11.5px;font-weight:700;color:var(--tx)">${icon} ${label} <span style="background:rgba(239,68,68,.15);color:var(--er);border-radius:10px;padding:1px 7px;font-size:10px">${arr.length}</span></span>
      </div>
      ${arr.slice(0,5).map(p=>`<div style="padding:7px 12px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border);font-size:11px">
        <span style="color:var(--t2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:180px">${esc(p.site)} — ${esc(p.user)}</span>
        <button class="sec-fix-btn" data-pid="${p.id}" style="background:rgba(59,130,246,.1);border:1px solid rgba(59,130,246,.2);border-radius:4px;padding:2px 8px;color:var(--ac);font-size:10px;cursor:pointer;font-family:inherit">Fix</button>
      </div>`).join('')}
      ${arr.length>5?`<div style="padding:6px 12px;font-size:10px;color:var(--t3)">${arr.length-5} more...</div>`:''}
    </div>`;
  }

  g.innerHTML = `
    <div style="text-align:center;padding:16px 12px 10px">
      <div style="font-size:2.8rem;font-weight:900;font-family:'Orbitron',monospace;color:${scoreColor};line-height:1">${score}</div>
      <div style="font-size:11px;color:var(--t2);margin-top:3px">${scoreLabel} — ${total} passwords</div>
      <div style="height:4px;background:var(--s3);border-radius:4px;margin:10px 16px 0;overflow:hidden">
        <div style="height:100%;width:${score}%;background:${scoreColor};border-radius:4px;transition:width .5s"></div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px;padding:6px 12px 12px">
      <div style="background:var(--s2);border:1px solid var(--border2);border-radius:7px;padding:8px;text-align:center">
        <div style="font-size:1.3rem;font-weight:800;color:${weak.length?'var(--er)':'var(--ok)'}">${weak.length}</div>
        <div style="font-size:9px;color:var(--t3);margin-top:2px">Weak</div>
      </div>
      <div style="background:var(--s2);border:1px solid var(--border2);border-radius:7px;padding:8px;text-align:center">
        <div style="font-size:1.3rem;font-weight:800;color:${reusedList.length?'var(--wn)':'var(--ok)'}">${reusedList.length}</div>
        <div style="font-size:9px;color:var(--t3);margin-top:2px">Reused</div>
      </div>
      <div style="background:var(--s2);border:1px solid var(--border2);border-radius:7px;padding:8px;text-align:center">
        <div style="font-size:1.3rem;font-weight:800;color:${old90.length?'var(--wn)':'var(--ok)'}">${old90.length}</div>
        <div style="font-size:9px;color:var(--t3);margin-top:2px">Old (90d+)</div>
      </div>
    </div>
    <div style="padding:0 12px 12px">
      ${issueList(weak,'⚠️','Weak Passwords','')}
      ${issueList(reusedList,'♻️','Reused Passwords','')}
      ${issueList(old90,'🕐','Old Passwords (90+ days)','')}
    </div>`;
}

async function encData(data, pw) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv   = crypto.getRandomValues(new Uint8Array(12));
  const key  = await deriveKey(pw, salt);
  const ct   = await crypto.subtle.encrypt({ name:'AES-GCM', iv }, key, new TextEncoder().encode(JSON.stringify(data)));
  const buf  = new Uint8Array(16 + 12 + ct.byteLength);
  buf.set(salt,0); buf.set(iv,16); buf.set(new Uint8Array(ct),28);
  let bin=''; buf.forEach(b => bin += String.fromCharCode(b));
  return btoa(bin);
}

// ═══════════════════════════════════════════════════════
// TOTP / OTP GENERATOR — RFC 6238 compliant
// Works exactly like Google Authenticator
// ═══════════════════════════════════════════════════════

// Base32 decode
function b32decode(s) {
  const ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  s = s.replace(/=+$/,'').toUpperCase().replace(/[^A-Z2-7]/g,'');
  let bits=0, val=0; const out=[];
  for (const c of s) {
    val = (val<<5)|ALPHA.indexOf(c); bits+=5;
    if(bits>=8){out.push((val>>>(bits-8))&255);bits-=8;}
  }
  return new Uint8Array(out);
}

// HMAC-SHA1 via SubtleCrypto
async function hmacSha1(keyBytes, msgBytes) {
  const key = await crypto.subtle.importKey('raw', keyBytes, {name:'HMAC',hash:'SHA-1'}, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, msgBytes);
  return new Uint8Array(sig);
}

// Generate TOTP code — RFC 6238
async function genTOTP(secret, digits=6, period=30) {
  const key = b32decode(secret);
  const counter = Math.floor(Date.now()/1000/period);
  const msg = new Uint8Array(8);
  let c = counter;
  for(let i=7;i>=0;i--){msg[i]=c&0xff;c>>>=8;}
  const h = await hmacSha1(key, msg);
  const offset = h[h.length-1]&0xf;
  const code = ((h[offset]&0x7f)<<24|(h[offset+1]&0xff)<<16|(h[offset+2]&0xff)<<8|(h[offset+3]&0xff))%(10**digits);
  return String(code).padStart(digits,'0');
}

// ── OTP Account management ──
function addOtpAccount() {
  const site = document.getElementById('otpSite')?.value.trim();
  const secret = document.getElementById('otpSecret')?.value.trim().replace(/\s/g,'');
  if(!site||!secret){toast('Site name aur Secret key zaroori hai!','er');return;}
  // Validate secret
  try { b32decode(secret); } catch(e) { toast('Invalid Base32 secret key!','er'); return; }
  if(!V.otp)V.otp=[];
  const existing = V.otp.findIndex(o=>o.site.toLowerCase()===site.toLowerCase());
  const entry = {id:uid(),site,secret,digits:6,period:30,created:new Date().toISOString()};
  if(existing>=0){V.otp[existing]=entry;}else{V.otp.push(entry);}
  saveVault();
  document.getElementById('otpSite').value='';
  document.getElementById('otpSecret').value='';
  toast('✓ OTP account added!');
  renderOtp();
}

let otpTimers = {};
async function renderOtp() {
  const g = document.getElementById('otpList');
  if(!g)return;
  if(!V.otp||!V.otp.length){
    g.innerHTML=`<div class="empty">
      <div class="empty-ic" style="opacity:.3"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg></div>
      <div class="empty-t">Koi OTP account nahi</div>
      <div class="empty-s">QR scan ya secret key add karein</div>
    </div>`;
    return;
  }
  // Clear old timers
  Object.values(otpTimers).forEach(clearInterval);
  otpTimers={};

  const period=30;
  const remaining=()=>period-Math.floor(Date.now()/1000%period);
  const pct=()=>Math.round((remaining()/period)*100);

  g.innerHTML=V.otp.map((o,i)=>`
    <div class="pwc" id="otp-card-${o.id}">
      <div class="pwc-top">
        <div class="pwc-av av-other" style="font-size:13px">${(o.site||'?')[0].toUpperCase()}</div>
        <div class="pwc-name">${esc(o.site)}</div>
        <span class="pwc-cat cat-other">${o.digits}d / ${o.period}s</span>
      </div>
      <div style="display:flex;align-items:center;gap:10px;margin:6px 0">
        <div id="otp-code-${o.id}" style="font-family:'SF Mono',monospace;font-size:22px;font-weight:700;letter-spacing:4px;color:var(--ac);flex:1;cursor:pointer" title="Click to copy">••• •••</div>
        <div style="position:relative;width:32px;height:32px;flex-shrink:0">
          <svg width="32" height="32" viewBox="0 0 36 36" style="transform:rotate(-90deg)">
            <circle cx="18" cy="18" r="15" fill="none" stroke="var(--s3)" stroke-width="3"/>
            <circle id="otp-ring-${o.id}" cx="18" cy="18" r="15" fill="none" stroke="var(--ac)" stroke-width="3" stroke-dasharray="94.2" stroke-dashoffset="${94.2-(94.2*pct()/100)}" stroke-linecap="round"/>
          </svg>
          <div id="otp-secs-${o.id}" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;color:var(--t2)">${remaining()}</div>
        </div>
      </div>
      <div class="card-acts">
        <button class="ca-btn otp-cp-btn" data-oid="${o.id}">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
          Copy
        </button>
        <button class="ca-btn del otp-del-btn" data-oid="${o.id}">
          <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/></svg>
          Delete
        </button>
      </div>
    </div>`).join('');

  // Generate and update codes every second
  async function updateAllOtp(){
    for(const o of (V.otp||[])){
      try{
        const code = await genTOTP(o.secret, o.digits||6, o.period||30);
        const formatted = code.slice(0,3)+' '+code.slice(3);
        const el = document.getElementById(`otp-code-${o.id}`);
        if(el) el.textContent=formatted;
        // Update ring
        const ring = document.getElementById(`otp-ring-${o.id}`);
        const secsEl = document.getElementById(`otp-secs-${o.id}`);
        const rem = remaining();
        if(ring) ring.setAttribute('stroke-dashoffset', 94.2-(94.2*(rem/(o.period||30))));
        if(secsEl) secsEl.textContent=rem;
        // Color warning when <7s
        if(el) el.style.color = rem<7?'var(--er)':'var(--ac)';
      }catch(e){}
    }
  }
  updateAllOtp();
  otpTimers['main']=setInterval(updateAllOtp,1000);
}

async function cpOtp(id){
  const o=V.otp?.find(x=>x.id===id); if(!o)return;
  try{
    const code=await genTOTP(o.secret,o.digits||6,o.period||30);
    navigator.clipboard.writeText(code).then(()=>toast('✓ OTP copied!'));
  }catch(e){toast('Error generating OTP','er');}
}

function delOtp(id){
  if(!confirm('Delete this OTP account?'))return;
  V.otp=(V.otp||[]).filter(o=>o.id!==id);
  saveVault(); renderOtp(); toast('OTP deleted','wn');
}

// ═══════════════════════════════════════════════════════
// BREACH CHECK — HaveIBeenPwned API (k-Anonymity model)
// Only sends first 5 chars of SHA-1 hash — private!
// ═══════════════════════════════════════════════════════

async function sha1hex(str) {
  const buf = await crypto.subtle.digest('SHA-1', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('').toUpperCase();
}

async function checkPwnedPassword(pw) {
  try {
    const hash = await sha1hex(pw);
    const prefix = hash.slice(0,5);
    const suffix = hash.slice(5);
    const res = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
      headers:{'Add-Padding':'true'}
    });
    if(!res.ok) return -1; // API error
    const text = await res.text();
    const lines = text.split('\n');
    for(const line of lines){
      const [h,count] = line.split(':');
      if(h.trim()===suffix) return parseInt(count.trim());
    }
    return 0; // Not found — safe!
  } catch(e) { return -1; } // Network error
}

async function runBreachCheck() {
  const g = document.getElementById('secContent');
  if(!g||!V.pw.length) return;

  // Show loading
  const btn = document.getElementById('breachCheckBtn');
  if(btn){btn.disabled=true;btn.textContent='Checking...';}

  const results = [];
  let checked=0;
  for(const p of V.pw){
    if(!p.pw)continue;
    const count = await checkPwnedPassword(p.pw);
    if(count>0) results.push({...p,breachCount:count});
    checked++;
    if(btn) btn.textContent=`Checking ${checked}/${V.pw.length}...`;
    // Small delay to avoid rate limiting
    await new Promise(r=>setTimeout(r,80));
  }

  if(btn){btn.disabled=false;btn.textContent='Re-check Breaches';}

  const breachEl = document.getElementById('breach-results');
  if(!breachEl) return;

  if(!results.length){
    breachEl.innerHTML=`<div style="display:flex;align-items:center;gap:8px;padding:10px 12px;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.2);border-radius:8px;font-size:12px;color:var(--ok)">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
      <span>Koi breach nahi mili! Sab ${checked} passwords safe hain.</span>
    </div>`;
    return;
  }

  breachEl.innerHTML=`<div style="background:rgba(239,68,68,.06);border:1px solid rgba(239,68,68,.2);border-radius:8px;overflow:hidden;margin-bottom:8px">
    <div style="padding:8px 12px;border-bottom:1px solid rgba(239,68,68,.15);font-size:12px;font-weight:700;color:var(--er)">
      ⚠️ ${results.length} passwords leaked data breaches mein mili!
    </div>
    ${results.map(p=>`<div style="padding:8px 12px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;font-size:11px">
      <div>
        <span style="color:var(--tx);font-weight:600">${esc(p.site)}</span>
        <span style="color:var(--t2);margin-left:6px">${esc(p.user)}</span>
      </div>
      <div style="display:flex;align-items:center;gap:6px">
        <span style="color:var(--er);font-size:10px">${p.breachCount.toLocaleString()}x leaked</span>
        <button class="breach-fix-btn" data-pid="${p.id}" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);border-radius:4px;padding:2px 7px;color:var(--er);font-size:10px;cursor:pointer;font-family:inherit">Change</button>
      </div>
    </div>`).join('')}
  </div>`;
}

// ═══ UPGRADE renderSec with Breach Check button ═══
const _origRenderSec = renderSec;
renderSec = function() {
  _origRenderSec();
  // Add breach check section after score
  const g = document.getElementById('secContent');
  if(!g||!V.pw.length) return;
  const breachSection = document.createElement('div');
  breachSection.style.cssText='padding:0 12px 12px';
  breachSection.innerHTML=`
    <div style="background:var(--s2);border:1px solid var(--border2);border-radius:8px;padding:12px;margin-bottom:8px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
        <div>
          <div style="font-size:12px;font-weight:700;color:var(--tx)">🔍 Breach Check</div>
          <div style="font-size:10px;color:var(--t3);margin-top:2px">HaveIBeenPwned API — k-Anonymity (safe)</div>
        </div>
        <button id="breachCheckBtn" class="btn btn-sec" style="font-size:10.5px;padding:6px 12px">
          Check Breaches
        </button>
      </div>
      <div id="breach-results">
        <div style="font-size:11px;color:var(--t3)">"Check Breaches" pe click karo — koi password leaked hai kya check karega</div>
      </div>
    </div>`;
  g.appendChild(breachSection);
};

